package com.tracfone.inquiry.verizon.events;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(SpringRunner.class)
public class TracfonePublisherTest {
    @Spy
    private TracfonePublisher tracfonePublisher;
    @Mock
    private ApplicationEventPublisher applicationEventPublisher;
    @MockBean
    private TracfoneEvent event;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(tracfonePublisher, "applicationEventPublisher", applicationEventPublisher);
    }

    @Test
    public void testSendMessage() {
        Mockito.doNothing().when(applicationEventPublisher).publishEvent(any());
        tracfonePublisher.sendMessage(event);
        verify(applicationEventPublisher, times(1)).publishEvent(any());
    }
}