package com.tracfone.inquiry.verizon.helper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = {"verizon.service.url=url", "verizon.service.userId=userId",
        "verizon.service.password=password", "verizon.bucket.userId=userId",
        "verizon.bucket.password=password", "verizon.bucket.url=url"})
public class PropertyHelperTest {
    @Value("${verizon.service.url}")
    private String serviceURL;

    @Value("${verizon.service.userId}")
    private String userId;

    @Value("${verizon.service.password}")
    private String password;

    @Value("${verizon.bucket.url}")
    private String bucketURL;

    @Value("${verizon.bucket.userId}")
    private String bucketUserId;

    @Value("${verizon.bucket.password}")
    private String bucketPassword;

    @Spy
    private PropertyHelper propertyHelper;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(propertyHelper, "serviceURL", serviceURL);
        ReflectionTestUtils.setField(propertyHelper, "userId", userId);
        ReflectionTestUtils.setField(propertyHelper, "password", password);
        ReflectionTestUtils.setField(propertyHelper, "bucketURL", bucketURL);
        ReflectionTestUtils.setField(propertyHelper, "bucketUserId", bucketUserId);
        ReflectionTestUtils.setField(propertyHelper, "bucketPassword", bucketPassword);
    }

    @Test
    public void testSettersAndGetters() {
        propertyHelper.setServiceURL(serviceURL);
        propertyHelper.setUserId(userId);
        propertyHelper.setPassword(password);
        propertyHelper.setServiceURL(bucketURL);
        propertyHelper.setBucketUserId(bucketUserId);
        propertyHelper.setBucketPassword(bucketPassword);
        assertEquals(serviceURL, PropertyHelper.getServiceURL());
        assertEquals(userId, PropertyHelper.getUserId());
        assertEquals(password, PropertyHelper.getPassword());
        assertEquals(bucketURL, PropertyHelper.getBucketURL());
        assertEquals(bucketUserId, PropertyHelper.getUserId());
        assertEquals(bucketPassword, PropertyHelper.getPassword());
    }

}