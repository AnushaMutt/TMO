package com.tracfone.inquiry.verizon.controller;

import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.verizon.events.TracfonePublisher;
import com.tracfone.inquiry.verizon.service.InquiryVerizonService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class InquiryVerizonControllerTest {
    private static final String MIN = "7862124910";
    private static final String SIM = "8901260025195492064";
    @Spy
    private InquiryVerizonController inquiryVerizonController;
    @MockBean
    private InquiryVerizonService inquiryVerizonService;
    @MockBean
    private Environment env;

    @MockBean
    private TracfonePublisher publisher;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(inquiryVerizonController, "inquiryVerizonService", inquiryVerizonService);
        ReflectionTestUtils.setField(inquiryVerizonController, "env", env);
        ReflectionTestUtils.setField(inquiryVerizonController, "publisher", publisher);
    }

    @Test
    public void testBalanceInquiry() {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = populateResponse();
        when(inquiryVerizonService.inquireVZWByMin(any())).thenReturn(tfOneCarrierSubscriber);
        doReturn("on").when(env).getProperty("tracfoneEvent");
        inquiryVerizonController.balanceInquiryByMin(MIN);
        verify(inquiryVerizonService, times(1)).inquireVZWByMin(any());
    }

    @Test
    public void testBalanceInquiry_whenException() {
        doReturn("on").when(env).getProperty("tracfoneEvent");
        doThrow(TFMicroServiceException.class).when(inquiryVerizonService).inquireVZWByMin(any());
        inquiryVerizonController.balanceInquiryByMin(MIN);
        verify(inquiryVerizonService, times(1)).inquireVZWByMin(any());
    }

    private TFOneCarrierSubscriber populateResponse() {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setMin(MIN);
        tfOneCarrierSubscriber.setErrorCode("200");
        return tfOneCarrierSubscriber;
    }

    @Test
    public void testBalanceInquiryBySim() {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = populateResponse();
        when(inquiryVerizonService.inquireVZWByImsi(any())).thenReturn(tfOneCarrierSubscriber);
        doReturn("on").when(env).getProperty("tracfoneEvent");
        inquiryVerizonController.balanceInquiryBySim(SIM);
        verify(inquiryVerizonService, times(1)).inquireVZWByImsi(any());
    }

    @Test
    public void testBalanceInquiryBySim_whenException() {
        doReturn("on").when(env).getProperty("tracfoneEvent");
        doThrow(TFMicroServiceException.class).when(inquiryVerizonService).inquireVZWByImsi(any());
        inquiryVerizonController.balanceInquiryBySim(SIM);
        verify(inquiryVerizonService, times(1)).inquireVZWByImsi(any());
    }

    @Test
    public void testValidateSim() {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = populateResponse();
        when(inquiryVerizonService.validateSimByIccid(any())).thenReturn(tfOneCarrierSubscriber);
        doReturn("on").when(env).getProperty("tracfoneEvent");
        inquiryVerizonController.validateSim(SIM);
        verify(inquiryVerizonService, times(1)).validateSimByIccid(any());
    }

    @Test
    public void testValidateSim_whenException() {
        doReturn("on").when(env).getProperty("tracfoneEvent");
        doThrow(TFMicroServiceException.class).when(inquiryVerizonService).validateSimByIccid(any());
        inquiryVerizonController.validateSim(SIM);
        verify(inquiryVerizonService, times(1)).validateSimByIccid(any());
    }

}