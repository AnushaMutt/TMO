package com.tracfone.inquiry.verizon.config;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


@RunWith(SpringRunner.class)
public class AppConfigTest {

    @Spy
    private AppConfig appConfig;

    @Mock
    private RestTemplateBuilder builder;

    @Test
    public void testServletRegistrationBean() {
        assertNotNull(appConfig.servletRegistrationBean());
    }

    @Test
    public void testRestTemplate() {
        assertEquals(null, appConfig.restTemplate(builder));
    }
}