package com.tracfone.inquiry.verizon.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PropertyHelper {

    private static String serviceURL;

    public static String getServiceURL() {
        return serviceURL;
    }

    @Value("${verizon.service.url}")
    public void setServiceURL(String serviceURL) {
        PropertyHelper.serviceURL = serviceURL;
    }

    private static String userId;

    public static String getUserId() {
        return userId;
    }

    @Value("${verizon.service.userId}")
    public void setUserId(String userId) {
        PropertyHelper.userId = userId;
    }

    private static String password;

    public static String getPassword() {
        return password;
    }

    @Value("${verizon.service.password}")
    public void setPassword(String password) {
        PropertyHelper.password = password;
    }

    private static String bucketURL;

    public static String getBucketURL() {
        return bucketURL;
    }

    @Value("${verizon.bucket.url}")
    public void setBucketURL(String bucketURL) {
        PropertyHelper.bucketURL = bucketURL;
    }

    private static String bucketUserId;

    public static String getBucketUserId() {
        return bucketUserId;
    }

    @Value("${verizon.bucket.userId}")
    public void setBucketUserId(String bucketUserId) {
        PropertyHelper.bucketUserId = bucketUserId;
    }

    private static String bucketPassword;

    public static String getBucketPassword() {
        return bucketPassword;
    }

    @Value("${verizon.bucket.password}")
    public void setBucketPassword(String bucketPassword) {
        PropertyHelper.bucketPassword = bucketPassword;
    }

}
