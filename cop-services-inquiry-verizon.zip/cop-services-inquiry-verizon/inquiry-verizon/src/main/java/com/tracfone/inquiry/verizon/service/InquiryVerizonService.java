package com.tracfone.inquiry.verizon.service;

import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;

public interface InquiryVerizonService {
    TFOneCarrierSubscriber inquireVZWByMin(String min);

    TFOneCarrierSubscriber inquireVZWByImsi(String sim);

    TFOneCarrierSubscriber validateSimByIccid(String sim);
}
