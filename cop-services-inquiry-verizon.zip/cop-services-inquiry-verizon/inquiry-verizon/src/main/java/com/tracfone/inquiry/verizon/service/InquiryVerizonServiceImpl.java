package com.tracfone.inquiry.verizon.service;

import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneActionItemBucket;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.common.model.response.TFOneFeatures;
import com.tracfone.inquiry.common.model.response.TFOneRatePlan;
import com.tracfone.inquiry.common.model.response.TFOneRatePlanProfile;
import com.tracfone.inquiry.verizon.constant.VerizonConstant;
import com.tracfone.inquiry.verizon.helper.PropertyHelper;
import com.tracfone.inquiry.verizon.util.VerizonHttpClient;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static com.tracfone.inquiry.verizon.constant.VerizonConstant.ERROR_CODE;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_BUCKETS;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_FAILED_RESPONSE;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_FEATURES;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_ICCID;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_MAKE;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_MIN;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_MODEL;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_RATEPLAN;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_RATE_IMEI;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_RATE_IMEI_HEX;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_RATE_SIM;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_SIM_RESPONSE;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.XPATH_STATUS;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.X_PATH_MAKE;
import static com.tracfone.inquiry.verizon.constant.VerizonConstant.X_PATH_MODEL;

@Log4j2
@Service
public class InquiryVerizonServiceImpl implements InquiryVerizonService {

    @Autowired
    VerizonHttpClient verizonHttpClient;

    /**
     * Inquires subscriber from VERIZON with MIN as argument.
     *
     * @param min
     * @return
     */
    public TFOneCarrierSubscriber inquireVZWByMin(String min) {
        return inquireVZW("<subOrder><resellerLineInquiry><mdn>" + min + "</mdn></resellerLineInquiry>", TFOneCarrierSubscriber.MIN);
    }

    /**
     * Inquires subscriber from VERIZON with SIM as argument.
     *
     * @param imsi
     * @return
     */
    public TFOneCarrierSubscriber inquireVZWByImsi(String imsi) {
        String min = null;
        String xmlResponse = createPayloadAndFireInquiry("<accountNumber>1161</accountNumber><subOrder><resellerImsiInquiry><imsi>" + imsi + "</imsi></resellerImsiInquiry>");
        //String xmlResponse = "<?xml version='1.0' encoding='UTF-8'?><resellerImsiResponse xsi:schemaLocation='http://www.verizonwireless.com/oas http://localhost:8080/schema/reseller.xsd' xmlns='http://www.verizonwireless.com/oas' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'><messageHeader><vendorId>TRACFONE</vendorId><referenceNumber>TF_3058074211_410128962_181108175325484_74</referenceNumber></messageHeader><imsiResponse><errorCode>00</errorCode><errorMessage>SUCCESSFULLY PROCESSED THE REQUEST</errorMessage><mdn>9013049883</mdn><statusCode>ACTIVE</statusCode><iccid>89148000005112873567</iccid><imsi>311480503165419</imsi></imsiResponse></resellerImsiResponse>";
        log.info("first verizon response for IMSI Call " + xmlResponse);
        String returnCode = getTextFromXPath(xmlResponse, ERROR_CODE);
        log.info("returnCode for IMSI Call" + returnCode);
        //Check the response code, if equal to 00 then proceed otherwise subscriber not found
        if (returnCode != null && returnCode.equals("00")) {
            min = getNodeListLastVal(getValueFromXPath(xmlResponse, "//imsiResponse/*[ self::mdn/text()]"));
            log.info("MIN identified from IMSI call is " + min);
        }
        return inquireVZWByMin(min);
    }

    @Override
    public TFOneCarrierSubscriber validateSimByIccid(String sim) {
        String xmlResponse = createPayloadAndFireSimValidation("<iccid>" + sim + "</iccid>");
        log.info("payload for validate sim " + xmlResponse);
        /*String xmlResponse = "<?xml version='1.0' encoding='UTF-8'?>\n" +
                "<validateSIMResponse xsi:schemaLocation='http://www.verizonwireless.com/oas http://localhost:8080/schema/reseller.xsd' xmlns='http://www.verizonwireless.com/oas' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>\n" +
                "<messageHeader>\n" +
                "<vendorId>TRACFONE</vendorId>\n" +
                "<requestType>ORDER</requestType>\n" +
                "<orderType>MNTMLND</orderType>\n" +
                "<referenceNumber>TF_T56121410841745668_13738144785_210117225949487_778</referenceNumber>\n" +
                "<returnURL>http://10.253.182.52/igate/verizon/mia/spec.do</returnURL>\n" +
                "<asyncErrorURL>http://10.253.182.52/igate/verizon/mia/spec.do</asyncErrorURL>\n" +
                "</messageHeader>\n" +
                "<simResponse>\n" +
                "<iccid>89148000006315846517</iccid>\n" +
                "<isValid>Y</isValid>\n" +
                "<isInDMD>Y</isInDMD>\n" +
                "<isLostOrStolen>N</isLostOrStolen>\n" +
                "<SIMType>Reseller</SIMType>\n" +
                "<SIMStatus>AA</SIMStatus>\n" +
                "<isSoftcardCapable>N</isSoftcardCapable>\n" +
                "<profile>AWLT007a</profile>\n" +
                "<equipment>\n" +
                "<make>GTO</make>\n" +
                "<model>Gemalto 4G SIM Wholesale</model>\n" +
                "</equipment>\n" +
                "<returnCode>S0051</returnCode>\n" +
                "<returnMessage>SIM is valid</returnMessage>\n" +
                "</simResponse>\n" +
                "</validateSIMResponse>\n";*/
        //Duplicate response
        /*String xmlResponse = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><resellerOrderResponse xmlns=\"http://www.verizonwireless.com/oas\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">             <messageHeader><vendorId>TRACFONE</vendorId><requestType>ORDER</requestType><orderType>MNTMLND</orderType><referenceNumber>TF_T56121410841745668_13738144785_210117225949487_778</referenceNumber><returnURL>http://10.253.182.52/igate/verizon/mia/spec.do</returnURL></messageHeader>\n" +
                "<orderResponse><returnCode>E1005</returnCode><returnMessage>Duplicate Order Request</returnMessage></orderResponse>\n" +
                "</resellerOrderResponse>";*/
        //Invalid SIM
        /*String xmlResponse = "<?xml version='1.0' encoding='UTF-8'?><resellerOrderResponse xmlns='http://www.verizonwireless.com/oas' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>\n" +
                "               <messageHeader><vendorId>TRACFONE</vendorId><requestType>ORDER</requestType><orderType>MNTMLND</orderType><referenceNumber>TF_T56121410841745668_13738144785_210117225949487_778</referenceNumber><returnURL>http://10.253.182.52/igate/verizon/mia/spec.do</returnURL></messageHeader>\n" +
                "<orderResponse><returnCode>E1008</returnCode><returnMessage>Schema validation failed:cvc-pattern-valid: Value '8901260025195492064' is not facet-valid with respect to pattern '[0-9]{20}' for type 'SIMCardType'.,cvc-type.3.1.3: The value '8901260025195492064' of element 'iccid' is not valid. </returnMessage></orderResponse>\n" +
                "</resellerOrderResponse>";*/
        return buildMap(xmlResponse);
    }

    private TFOneCarrierSubscriber buildMap(String carrierResponse) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        Map<String, String> validateSimMap = new HashMap<>();

        String xPathIccid = XPATH_ICCID;
        String xPathMake = XPATH_MAKE;
        String xPathModel = XPATH_MODEL;
        String xPathSimResponse = XPATH_SIM_RESPONSE;
        String xPathFailedResponse = XPATH_FAILED_RESPONSE;
        NodeList failureNodes = getValueFromXPath(carrierResponse, xPathFailedResponse);
        log.info("nodes for orderResponse " + failureNodes);
        collectAllProperties(validateSimMap, failureNodes);

        if (validateSimMap.isEmpty()) {
            subscriber.setSim(getNodeListLastVal(getValueFromXPath(carrierResponse, xPathIccid)));
            subscriber.setMake(getNodeListLastVal(getValueFromXPath(carrierResponse, xPathMake)));
            subscriber.setModel(getNodeListLastVal(getValueFromXPath(carrierResponse, xPathModel)));

            NodeList responseNodes = getValueFromXPath(carrierResponse, xPathSimResponse);
            log.info("nodes for simResponse " + responseNodes);
            collectAllProperties(validateSimMap, responseNodes);
        }

        log.info("Validate SIM Map " + validateSimMap);
        List<Map<String, String>> additionalFields = new ArrayList<>();
        additionalFields.add(validateSimMap);
        subscriber.setAdditionalFields(additionalFields);

        log.info("Response for validate SIM - " + subscriber);
        return subscriber;
    }

    private void collectAllProperties(Map<String, String> validateSimMap, NodeList responseNodes) {
        // Iterate all nodes under simResponse.
        log.info("nodes for simResponse " + responseNodes);
        for (int x = 0; x < responseNodes.getLength(); x++) {
            Node node = responseNodes.item(x);
            NodeList responseChildNodes = node.getChildNodes();

            // Iterate each field of the simResponse.
            for (int i = 0; i < responseChildNodes.getLength(); i++) {
                String nodeName = responseChildNodes.item(i).getNodeName();
                log.info("node name for validate sim is " + nodeName);
                String value = responseChildNodes.item(i).getTextContent();
                log.info("node value for validate sim is " + value);
                if (StringUtils.isNotBlank(value)) {
                    validateSimMap.put(nodeName, value);
                }
            }
        }
    }

    private String createPayloadAndFireSimValidation(String searchField) {
        String payload = VerizonConstant.VZW_INQ_START +
                getCredentials(false) +
                VerizonConstant.VZW_SIM_VLDTN_AFTER_CREDENTIALS1 +
                referenceNumber() +
                VerizonConstant.VZW_SIM_VLDTN_AFTER_CREDENTIALS2 +
                formattedDate() +
                VerizonConstant.VZW_SIM_VLDTN_AFTER_CREDENTIALS3 +
                searchField +
                VerizonConstant.VZW_SIM_VLDTN_END;
        log.info("payload - " + payload);
        return verizonHttpClient.post(payload, PropertyHelper.getServiceURL());
    }

    /**
     * Inquires first in Pre paid platform, if subscriber is not found, attempts
     * with Postpaid platform.
     *
     * @param searchField
     * @param searchType
     * @return
     */
    private TFOneCarrierSubscriber inquireVZW(String searchField, String searchType) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        String xmlResponse = createPayloadAndFireInquiry(searchField);
        //String xmlResponse = "<?xml version='1.0' encoding='UTF-8'?><resellerLineResponse xsi:schemaLocation='http://www.verizonwireless.com/oas http://localhost:8080/schema/reseller.xsd' xmlns='http://www.verizonwireless.com/oas' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'><messageHeader><vendorId>TRACFONE</vendorId><requestType>INQUIRE</requestType><orderType>INQSLND</orderType><referenceNumber>TF_6164984794_10319939734_200527052440089_249</referenceNumber></messageHeader><lineResponse><errorCode>00</errorCode><errorMessage>SUCCESSFULLY PROCESSED THE REQUEST</errorMessage><min>6168228414</min><mdn>6164984794</mdn><deviceId>357150092333220</deviceId><iccid>89148000004826065768</iccid><imsi>311480479331284</imsi><euimid>A00000979E30B0</euimid><statusCode>ACTIVE</statusCode><lteStatusCode>CN</lteStatusCode><FUSFExemptFlag>Y</FUSFExemptFlag><feature><featureCode>HD_VOICE_WIFI_CL_BLK</featureCode><includedWithPlan>N</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>R00_DATATIER</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>TF_4G_DATA_MDNLT_PP</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>TF_4G_SMS_MDNLT_PP</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>ALLROAMBLOCK</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>4G_3G_DATA_PROV_PP</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>BREWBLOCK</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>CFB</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>CFWD</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>CID</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>HD_VVM</featureCode><includedWithPlan>N</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>WS_QOS</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>4G_IPPOOL_NON_MPN</featureCode><includedWithPlan>N</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>CW</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>4G_INTERNET</featureCode><includedWithPlan>N</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>4G_MMS</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>4G_WMB_NETWORK</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>CONFCALL</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>MMS_TF_BULK_PP</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>PPSMSBLOCK</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>VOT_HD_VOICE</featureCode><includedWithPlan>N</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>CDMA</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>CFN</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><feature><featureCode>SUX_SP</featureCode><includedWithPlan>Y</includedWithPlan><subscribe>A</subscribe></feature><plan><planCode>TF_4GHD_MDNLT_PP_1K</planCode></plan><equipment><make>LOD</make><model>GPLML414DCGB</model><mode>4G</mode></equipment><initialServiceDate>04/12/2019 14:25:54</initialServiceDate></lineResponse></resellerLineResponse>\n";

        log.info("first verizon response " + xmlResponse);
        String returnCode = getTextFromXPath(xmlResponse, ERROR_CODE);
        log.info("returnCode " + returnCode);
        //Check the response code, if equal to 00 then proceed otherwise subscriber not found
        if (returnCode != null && returnCode.equals("00")) {
            subscriber = buildResponse(xmlResponse);
            subscriber.setLineFoundBy(searchType);
            // If found in prepaid, search for buckets.
            log.info("making call for buckets");
            List<TFOneActionItemBucket> buckets = inquireVZWForBuckets(subscriber.getMin());
            subscriber.setBuckets(buckets);
        }
        log.info("final subscriber being returned - " + subscriber);
        return subscriber;
    }

    private String createPayloadAndFireInquiry(String searchField) {
        String payload = VerizonConstant.VZW_INQ_START +
                getCredentials(false) +
                VerizonConstant.VZW_INQ_AFTER_CREDENTIALS1 +
                referenceNumber() +
                VerizonConstant.VZW_INQ_AFTER_CREDENTIALS2 +
                formattedDate() +
                VerizonConstant.VZW_INQ_AFTER_CREDENTIALS3 +
                searchField +
                VerizonConstant.VZW_INQ_END;
        log.info("payload - " + payload);
        return verizonHttpClient.post(payload, PropertyHelper.getServiceURL());
    }

    private String getCredentials(boolean isBucketCall) {
        String credentials = null;
        if (isBucketCall) {
            credentials = "<wsse:UsernameToken><wsse:Username>" + PropertyHelper.getBucketUserId() + "</wsse:Username>\n" +
                    "<wsse:Password>" + PropertyHelper.getBucketPassword() + "</wsse:Password></wsse:UsernameToken>\n";
        } else {
            credentials = "<userName>" + PropertyHelper.getUserId() + "</userName>\n" +
                    "<password>" + PropertyHelper.getPassword() + "</password>\n";
        }
        return credentials;
    }

    /**
     * Inquires subscriber buckets from ATT/Ericsson with MIN as argument.
     *
     * @param min
     * @return
     */
    private List<TFOneActionItemBucket> inquireVZWForBuckets(String min) {
        String payload = VerizonConstant.VZW_INQ_BUCKETS_START
                + getCredentials(true)
                + VerizonConstant.VZW_INQ_BUCKETS_AFTER_CREDENTIALS
                + "<mdn>" + min + "</mdn>"
                + VerizonConstant.VZW_INQ_BUCKETS_END;
        log.info("buckets payload - " + payload);
        ArrayList<TFOneActionItemBucket> buckets = new ArrayList<>();
        try {
            String xmlResponse = verizonHttpClient.post(payload, PropertyHelper.getBucketURL());
            //String xmlResponse = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Header/><soapenv:Body><api:searchBucketInfoResponse xmlns:api=\"http://www.vzw.com/wcct/int/api/\"><outputSearchBucketInfo><transactionContext><mdn>6164984794</mdn><transactionId>11591919072</transactionId><userId>r0pinca</userId><sysOrignId>DATAPOWER</sysOrignId><status>000</status></transactionContext><numberRecords>3</numberRecords><additionalRecords>N</additionalRecords><primaryBalance>0.0000</primaryBalance><BucketInfo><sweepOn>false</sweepOn><buckets><reid/><reTime>11/22/2019</reTime><balanceValue>221</balanceValue><sourceId>TFC</sourceId><uom>min</uom><bucketValue>221</bucketValue><expTime>01/01/2034</expTime><sourceValue>Cr Adj - Voice</sourceValue><bucketTypeID>500</bucketTypeID><canUpdate>true</canUpdate><canDelete>true</canDelete></buckets><buckets><reid/><reTime>11/22/2019</reTime><balanceValue>757035.00</balanceValue><sourceId>TFD</sourceId><uom>kb</uom><bucketValue>757035.00</bucketValue><expTime>01/01/2034</expTime><sourceValue>Cr Adj - Data</sourceValue><bucketTypeID>700</bucketTypeID><canUpdate>true</canUpdate><canDelete>true</canDelete></buckets><buckets><reid/><reTime>11/22/2019</reTime><balanceValue>4364</balanceValue><sourceId>TSM</sourceId><uom>msg</uom><bucketValue>4364</bucketValue><expTime>01/01/2034</expTime><sourceValue>Cr Adj - SMS/MMS</sourceValue><bucketTypeID>850</bucketTypeID><canUpdate>true</canUpdate><canDelete>true</canDelete></buckets><numBuckets>3</numBuckets></BucketInfo></outputSearchBucketInfo></api:searchBucketInfoResponse></soapenv:Body></soapenv:Envelope>";
            log.info("second verizon response " + xmlResponse);
            String xPathBuckets = XPATH_BUCKETS;
            String xPathErrorCode = ERROR_CODE;
            String errorCode = getNodeListLastVal(getValueFromXPath(xmlResponse, xPathErrorCode));

            if (errorCode == null || errorCode.equals("")) {
                NodeList bucketNodes = getValueFromXPath(xmlResponse, xPathBuckets);
                // Iterate all buckets.
                for (int x = 0; x < bucketNodes.getLength(); x++) {
                    Node node = bucketNodes.item(x);
                    NodeList bucketNode = node.getChildNodes();

                    TFOneActionItemBucket tfBucket = new TFOneActionItemBucket();
                    // Iterate each field of the bucket.
                    for (int i = 0; i < bucketNode.getLength(); i++) {
                        String nodeName = bucketNode.item(i).getNodeName();
                        String value = bucketNode.item(i).getTextContent();

                        if ("balanceValue".equals(nodeName)) {
                            tfBucket.setBucketBalance(value);
                        } else if ("bucketValue".equals(nodeName)) {
                            tfBucket.setBucketValue(value);
                        } else if ("sourceId".equals(nodeName)) {
                            tfBucket.setBucketId(value);
                        } else if ("expTime".equals(nodeName)) {
                            tfBucket.setExpirationDate(value);
                        }
                    }
                    buckets.add(tfBucket);

                }
            }
        } catch (Exception e) {
            log.error("Buckets call failed - ", e);
        }
        return buckets;
    }

    /**
     * Builds the subscriber response with all fields required.
     *
     * @param carrierResponse
     * @return
     */
    public TFOneCarrierSubscriber buildResponse(String carrierResponse) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        String xPathRatePlan = XPATH_RATEPLAN; //PLANCODE
        String xPathRateIMEIHex = XPATH_RATE_IMEI_HEX;
        String xPathRateIMEI = XPATH_RATE_IMEI;
        String xPathRateSIM = XPATH_RATE_SIM; //ICCID
        String xPathStatus = XPATH_STATUS; //statusCode
        String xPathMin = XPATH_MIN; //MDN
        String xPathMake = X_PATH_MAKE; //MAKE
        String xPathModel = X_PATH_MODEL;
        String xPathFeatures = XPATH_FEATURES;

        String ratePlan = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathRatePlan));
        String imei = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathRateIMEI));
        String imeiHEX = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathRateIMEIHex));
        String sim = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathRateSIM));
        String status = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathStatus));
        String min = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathMin));
        String make = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathMake));
        String model = getNodeListLastVal(getValueFromXPath(carrierResponse, xPathModel));

        ArrayList<String> features = nodeListToStrList(getValueFromXPath(carrierResponse, xPathFeatures));
        TFOneRatePlan tfRatePlan = buildRatePlanProfile(features, ratePlan);

        //Checking if imei is HEX or not
        if (imei == null || "".equalsIgnoreCase(imei)) {

            //Its a 3G device, convert the esnHEX to esn
            try {
                MeidHelper meidHelper = new MeidHelper(imeiHEX);
                imei = meidHelper.getMeidDec();
            } catch (Exception ex) {
                log.error(ex);
                imei = "";
            }
        }

        subscriber.setEsn(imei);
        subscriber.setSim(sim);
        subscriber.setRateplanProfile(tfRatePlan);
        subscriber.setLineStatus(status);
        subscriber.setMin(min);
        subscriber.setMake(make);
        subscriber.setModel(model);
        return subscriber;
    }

    private NodeList getValueFromXPath(String carrierResponse, String xPath) {
        NodeList nodeList = null;
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            docBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            docBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            // Disable external DTDs as well
            docBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new InputSource(new StringReader(carrierResponse)));
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile(xPath);
            nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        } catch (Exception e) {
            log.error(e);
            throw new TFMicroServiceException(VerizonConstant.TRACFONE_CARRIER_XMLPARSE_ERROR, VerizonConstant.TRACFONE_CARRIER_XMLPARSE_ERROR_MESSAGE, e.getMessage(), e);
        }

        return nodeList;
    }

    private String getTextFromXPath(String carrierResponse, String xPath) {
        String nodeValue = null;

        try {

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            docBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            docBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            // Disable external DTDs as well
            docBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new InputSource(new StringReader(carrierResponse)));
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile(xPath);
            nodeValue = expr.evaluate(doc);
        } catch (Exception e) {
            log.error(e);
            throw new TFMicroServiceException(VerizonConstant.TRACFONE_CARRIER_XMLPARSE_ERROR, VerizonConstant.TRACFONE_CARRIER_XMLPARSE_ERROR_MESSAGE, e.getMessage(), e);
        }

        return nodeValue;
    }

    private ArrayList<String> nodeListToStrList(NodeList nodeList) {
        ArrayList<String> strList = new ArrayList<>();

        for (int x = 0; x < nodeList.getLength(); x++) {
            Node node = nodeList.item(x);
            strList.add(node.getTextContent());
        }
        return strList;
    }

    /**
     * @param features
     * @param ratePlan
     * @return built object with rate plan and features.
     */
    private TFOneRatePlan buildRatePlanProfile(ArrayList<String> features, String ratePlan) {
        TFOneRatePlan tfRatePlan = new TFOneRatePlan();
        tfRatePlan.setRatePlanName(ratePlan);
        List<TFOneFeatures> tfFeatures = new ArrayList<>();

        for (String feat : features) {
            TFOneFeatures tfFeat = new TFOneFeatures();
            tfFeat.setFeatureValue(feat);
            tfFeatures.add(tfFeat);
        }

        TFOneRatePlanProfile tfRateplanProfile = new TFOneRatePlanProfile();
        tfRateplanProfile.setFeatures(tfFeatures);
        List<TFOneRatePlanProfile> ratePlanProfile = new ArrayList<>();
        ratePlanProfile.add(tfRateplanProfile);

        tfRatePlan.setRatePlanProfile(ratePlanProfile);
        return tfRatePlan;
    }

    private String getNodeListLastVal(NodeList nodeList) {
        String status = "";

        for (int x = 0; x < nodeList.getLength(); x++) {
            Node node = nodeList.item(x);
            status = node.getTextContent();
        }
        return status;
    }

    private static String formattedDate() {
        DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        return formatter.format(new Date());
    }

    private static String referenceNumber() {
        return "TF_COP" + Calendar.getInstance().getTimeInMillis();
    }

}

class MeidHelper {

    /* Serial Testing Patterns */
    private static final String MEID_DEC_TEST = "[0-9]{18}";
    private static final String MEID_HEX_TEST = "[a-fA-F0-9]{14}";
    private static final String ESN_DEC_TEST = "[0-9]{11}";
    private static final String ESN_HEX_TEST = "[a-fA-F0-9]{8}";
    private static final String NO_VALUE = " -- ";

    private CharSequence userInput;

    public boolean isMEID = false;
    public boolean isESN = false;
    public boolean isHEX = false;
    public boolean isDEC = false;

    public String inputString;
    public String meidDEC;
    public String meidHEX;
    public String esnHEX;
    public String esnDEC;
    public String metroSPC;

    /**
     * @param input
     * @throws Exception
     */
    public MeidHelper(CharSequence input) throws Exception {
        userInput = input;

        inputString = input.toString().toUpperCase();

        if (testInput(inputString, MEID_DEC_TEST)) {
            isMEID = true;
            isDEC = true;
        } else if (testInput(inputString, MEID_HEX_TEST)) {
            isMEID = true;
            isHEX = true;
        } else if (testInput(inputString, ESN_DEC_TEST)) {
            isESN = true;
            isDEC = true;
        } else if (testInput(inputString, ESN_HEX_TEST)) {
            isESN = true;
            isHEX = true;
        }
    }

    /**
     * @return
     */
    protected String getMeidDec() {
        if (meidDEC != null) { // already calculated
            return inputString;
        } else if (isESN) { // ESN/pESN Provided
            return NO_VALUE;
        } else if (isMEID && isDEC) {// given in this format
            meidDEC = inputString;
        } else {// convert HEX to DEC
            meidDEC = transformSerial(userInput, 16, 10, 8, 10, 8);
        }
        return meidDEC;
    }

    /**
     * Test a String against a Regular Expression
     *
     * @param input
     * @param regex
     * @return
     */
    protected boolean testInput(String input, String regex) {
        return Pattern.matches(regex, input);
    }

    /**
     * Returns a converted ESN/MEID based on specified paramters
     * See function userInput.setOnClickListener
     *
     * @param n
     * @param srcBase
     * @param dstBase
     * @param p1Width
     * @param p1Padding
     * @param p2Padding
     * @return
     */
    protected static String transformSerial(CharSequence n, int srcBase, int dstBase, int p1Width, int p1Padding, int p2Padding) {
        String p1 = lPad(Long.toString(Long.parseLong(n.toString().substring(0, p1Width), srcBase), dstBase), p1Padding, "0");
        String p2 = lPad(Long.toString(Long.parseLong(n.toString().substring(p1Width), srcBase), dstBase), p2Padding, "0");

        String c = p1 + p2;
        return c.toUpperCase();
    }

    /**
     * Returns a left padded string for DEC/HEX Conversion
     *
     * @param s
     * @param len
     * @param p
     * @return
     */
    protected static String lPad(String s, int len, String p) {
        if (s.length() >= len) {
            return s;
        }
        return lPad(p + s, len, p);
    }

}
