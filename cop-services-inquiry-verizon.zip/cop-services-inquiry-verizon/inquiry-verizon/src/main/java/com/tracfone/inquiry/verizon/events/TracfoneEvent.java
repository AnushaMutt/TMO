package com.tracfone.inquiry.verizon.events;

import org.springframework.context.ApplicationEvent;

public class TracfoneEvent extends ApplicationEvent {

    public TracfoneEvent(Object source) {
        super(source);
    }

    private long startTime;
    private long endTime;
    private String errorMessage;
    private String errorCode;
    private static String requestId;
    private String requestPayload;
    private String status;

    private static final long serialVersionUID = 1L;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }


    public static String getRequestId() {
        return requestId;
    }

    public static void setRequestId(String requestId) {
        TracfoneEvent.requestId = requestId;
    }

    public String getRequestPayload() {
        return requestPayload;
    }

    public void setRequestPayload(String requestPayload) {
        this.requestPayload = requestPayload;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

}
