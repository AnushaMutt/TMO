package com.tracfone.inquiry.verizon.events;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class TracfonePublisher {

    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;


    public void sendMessage(TracfoneEvent event) {
        log.info("Publishing custom Tracfone event. ");
        applicationEventPublisher.publishEvent(event);

    }

}
