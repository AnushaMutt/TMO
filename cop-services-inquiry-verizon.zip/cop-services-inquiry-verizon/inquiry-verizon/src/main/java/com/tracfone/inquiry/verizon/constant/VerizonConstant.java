package com.tracfone.inquiry.verizon.constant;

public class VerizonConstant {

    public static final String CARRIER_VZW = "VZW";

    public static final String TRACFONE_CARRIER_XMLPARSE_ERROR = "TFE600";
    public static final String TRACFONE_CARRIER_XMLPARSE_ERROR_MESSAGE = "Failed to parse XML response from carrier.";
    public static final String VZW_INQ_START = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<resellerOrder xsi:schemaLocation=\"http://www.verizonwireless.com/oas http://localhost:8080/schema/reseller.xsd\" xmlns=\"http://www.verizonwireless.com/oas\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
            "               <messageHeader>\n";
    public static final String VZW_INQ_AFTER_CREDENTIALS1 = "<vendorId>TRACFONE</vendorId>\n" +
            "                              <requestType>INQUIRE</requestType>\n" +
            "                              <orderType>INQSLND</orderType>\n" +
            "                              <referenceNumber>";
    public static final String VZW_INQ_AFTER_CREDENTIALS2 = "</referenceNumber><returnURL/></messageHeader><order><orderTimeStamp>";
    public static final String VZW_INQ_AFTER_CREDENTIALS3 = "</orderTimeStamp>\n";

    public static final String VZW_INQ_END = "</subOrder>\n" +
            "               </order>\n" +
            "</resellerOrder>";

    public static final String VZW_INQ_BUCKETS_START = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:api=\"http://www.vzw.com/wcct/int/api/\">\n" +
            "               <soapenv:Header>\n" +
            "                              <wsse:Security xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n";
    public static final String VZW_INQ_BUCKETS_AFTER_CREDENTIALS = "</wsse:Security>\n" +
            "               </soapenv:Header>\n" +
            "               <soapenv:Body>\n" +
            "                              <api:searchBucketInfo>\n" +
            "                                             <inputSearchBucketInfo>\n" +
            "                                                            <userId>r0pinca</userId>\n" +
            "                                                            <transactionId/>";

    public static final String VZW_INQ_BUCKETS_END = "<balanceType>both</balanceType>\n" +
            "                                             </inputSearchBucketInfo>\n" +
            "                              </api:searchBucketInfo>\n" +
            "               </soapenv:Body>\n" +
            "</soapenv:Envelope>";

    public static final String VZW_SIM_VLDTN_AFTER_CREDENTIALS1 = "<vendorId>TRACFONE</vendorId>\n" +
            "<requestType>ORDER</requestType>\n" +
            "<orderType>MNTMLND</orderType>\n" +
            "<referenceNumber>";
    public static final String VZW_SIM_VLDTN_AFTER_CREDENTIALS2 = "</referenceNumber>\n" +
            "<returnURL>http://10.253.182.52/igate/verizon/mia/spec.do</returnURL>\n" +
            "<asyncErrorURL>http://10.253.182.52/igate/verizon/mia/spec.do</asyncErrorURL>\n" +
            "</messageHeader>\n" +
            "<order>\n" +
            "<orderTimeStamp>";
    public static final String VZW_SIM_VLDTN_AFTER_CREDENTIALS3 = "</orderTimeStamp>\n" +
            "<accountNumber>1161</accountNumber>\n" +
            "<subOrder>\n" +
            "<validateSIM>";

    public static final String VZW_SIM_VLDTN_END = "</validateSIM>\n" +
            "</subOrder>\n" +
            "</order>\n" +
            "</resellerOrder>";

    public static final String ERROR_CODE = "//errorCode/text()";
    public static final String XPATH_ICCID = "//simResponse/iccid/text()";
    public static final String XPATH_MAKE = "//simResponse/equipment/*[ self::make/text()]";
    public static final String XPATH_MODEL = "//simResponse/equipment/*[ self::model/text()]";
    public static final String XPATH_SIM_RESPONSE = "//simResponse";
    public static final String XPATH_FAILED_RESPONSE = "//orderResponse";
    public static final String XPATH_BUCKETS = "//BucketInfo/buckets";
    public static final String XPATH_RATEPLAN = "//lineResponse/plan/planCode/text()";
    public static final String XPATH_RATE_IMEI_HEX = "//lineResponse/*[ self::meid/text()]";
    public static final String XPATH_RATE_IMEI = "//lineResponse/*[ self::deviceId/text()]";
    public static final String XPATH_RATE_SIM = "//lineResponse/*[ self::iccid/text()]";
    public static final String XPATH_STATUS = "//lineResponse/*[ self::statusCode/text()]";
    public static final String XPATH_MIN = "//lineResponse/*[ self::mdn/text()]";
    public static final String X_PATH_MAKE= "//lineResponse/equipment/*[ self::make/text()]";
    public static final String X_PATH_MODEL = "//lineResponse/equipment/*[ self::model/text()]";
    public static final String XPATH_FEATURES = "//feature[subscribe='A']/featureCode/text()";
    public static final String EVENT_STATUS = "Event Status is::";
    public static final String TRACFONE_STATUS = "tracfoneEvent";
}
