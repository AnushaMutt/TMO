package com.tracfone.inquiry.verizon.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tracfone.inquiry.common.exception.ExceptionHandlerUtil;
import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.verizon.constant.VerizonConstant;
import com.tracfone.inquiry.verizon.events.TracfoneEvent;
import com.tracfone.inquiry.verizon.events.TracfonePublisher;
import com.tracfone.inquiry.verizon.service.InquiryVerizonService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@Log4j2
@RestController
@RequestMapping(path = "/api/verizon")
public class InquiryVerizonController {

    @Autowired
    InquiryVerizonService inquiryVerizonService;

    @Autowired
    Environment env;

    @Autowired
    TracfonePublisher publisher;

    /**
     * Balance inquiry Rest service.
     * <p>
     * http://localhost:8082/api/verizon/inquiry/min/7862124910
     *
     * @param min
     * @return
     */
    @GetMapping(value = "/inquiry/min/{minnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity balanceInquiryByMin(@PathVariable("minnumber") String min) {
        log.info("Service called");
        log.info("Request received = min:" + min);
        TFOneCarrierSubscriber response = null;
        TracfoneEvent event = new TracfoneEvent(this);
        try {
            String payloadJson = buildPayload("min", min);

            if (payloadJson != null) {
                event.setRequestPayload(payloadJson);
            }

            event.setStartTime(System.currentTimeMillis());
            response = inquiryVerizonService.inquireVZWByMin(min);
            event.setEndTime(System.currentTimeMillis());
            log.info("Event Status is::" + env.getProperty("tracfoneEvent"));
            if (env.getProperty("tracfoneEvent").equalsIgnoreCase("on")) {
                publisher.sendMessage(event);
            }
            log.info("************Event Metrics**************");
            event.setStatus(response.getStatus());
            log.info("RequestID::" + TracfoneEvent.getRequestId());
            log.info("Status::" + event.getStatus());
            log.info("Request Payload::" + event.getRequestPayload());
            log.info("************Event Metrics**************");
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            event.setStatus(response.getStatus());
            event.setErrorCode(response.getErrorCode());
            event.setErrorMessage(response.getErrorMessage());
            log.info("************Event Metrics**************");
            log.info("RequestID::" + TracfoneEvent.getRequestId());
            log.info("Status::" + event.getStatus());
            log.info("Error Code::" + event.getErrorCode());
            log.info("Error Message::" + event.getErrorMessage());
            log.info("Request Payload::" + event.getRequestPayload());
            log.info("************Event Metrics**************");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.info("Service Ended");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Balance inquiry Rest service.
     * <p>
     * http://localhost:8082/api/verizon/inquiry/sim/7862124910
     *
     * @param sim
     * @return
     */
    @GetMapping(value = "/inquiry/sim/{simnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity balanceInquiryBySim(@PathVariable("simnumber") String sim) {
        log.info("Service called");
        log.info("Request received = sim:" + sim);
        TFOneCarrierSubscriber response = null;
        TracfoneEvent event = new TracfoneEvent(this);
        try {
            String payloadJson = buildPayload("sim", sim);

            if (payloadJson != null) {
                event.setRequestPayload(payloadJson);
            }

            event.setStartTime(System.currentTimeMillis());
            response = inquiryVerizonService.inquireVZWByImsi(sim);
            event.setEndTime(System.currentTimeMillis());
            log.info("Event Status is::" + env.getProperty("tracfoneEvent"));
            if (env.getProperty("tracfoneEvent").equalsIgnoreCase("on")) {
                publisher.sendMessage(event);
            }
            log.info("************Event Metrics**************");
            event.setStatus(response.getStatus());
            log.info("RequestID::" + TracfoneEvent.getRequestId());
            log.info("Status::" + event.getStatus());
            log.info("Request Payload::" + event.getRequestPayload());
            log.info("************Event Metrics**************");
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            event.setStatus(response.getStatus());
            event.setErrorCode(response.getErrorCode());
            event.setErrorMessage(response.getErrorMessage());
            log.info("************Event Metrics**************");
            log.info("RequestID::" + TracfoneEvent.getRequestId());
            log.info("Status::" + event.getStatus());
            log.info("Error Code::" + event.getErrorCode());
            log.info("Error Message::" + event.getErrorMessage());
            log.info("Request Payload::" + event.getRequestPayload());
            log.info("************Event Metrics**************");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.info("Service Ended");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/validate/sim/{simnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity validateSim(@PathVariable("simnumber") String sim) {
        log.info("Validate SIM Service called");
        log.info("Request received = sim:" + sim);
        TFOneCarrierSubscriber response = null;
        TracfoneEvent event = new TracfoneEvent(this);
        try {
            String payloadJson = buildPayload("sim", sim);

            if (payloadJson != null) {
                event.setRequestPayload(payloadJson);
            }

            event.setStartTime(System.currentTimeMillis());
            response = inquiryVerizonService.validateSimByIccid(sim);
            event.setEndTime(System.currentTimeMillis());
            log.info("Event Status is::" + env.getProperty("tracfoneEvent"));
            if (env.getProperty("tracfoneEvent").equalsIgnoreCase("on")) {
                publisher.sendMessage(event);
            }
            log.info("************Event Metrics**************");
            event.setStatus(response.getStatus());
            log.info("RequestID::" + TracfoneEvent.getRequestId());
            log.info("Status::" + event.getStatus());
            log.info("Request Payload::" + event.getRequestPayload());
            log.info("************Event Metrics**************");
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            event.setStatus(response.getStatus());
            event.setErrorCode(response.getErrorCode());
            event.setErrorMessage(response.getErrorMessage());
            log.info("************Event Metrics**************");
            log.info("RequestID::" + TracfoneEvent.getRequestId());
            log.info("Status::" + event.getStatus());
            log.info("Error Code::" + event.getErrorCode());
            log.info("Error Message::" + event.getErrorMessage());
            log.info("Request Payload::" + event.getRequestPayload());
            log.info("************Event Metrics**************");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.info("Service Ended");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private String buildPayload(String type, String value) {
        Map<String, String> payload = new HashMap<String, String>();
        payload.put(type, value);
        payload.put("carrier", VerizonConstant.CARRIER_VZW);
        String json = null;
        try {
            json = new ObjectMapper().writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
    }

}
