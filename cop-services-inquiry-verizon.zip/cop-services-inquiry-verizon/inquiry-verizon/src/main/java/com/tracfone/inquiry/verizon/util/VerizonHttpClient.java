package com.tracfone.inquiry.verizon.util;

import com.tracfone.inquiry.common.constant.TFMicroServicesConstant;
import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.verizon.filter.CorrelationIDFilter;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Log4j2
@Component
public class VerizonHttpClient {

    @Autowired
    RestTemplate restTemplate;

    public String post(String requestBody, String url) {
        log.info("post method called ");
        log.info("Request : " + requestBody);
        ResponseEntity<String> response = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_XML);
            headers.set(CorrelationIDFilter.CORRELATION_ID_KEY, ThreadContext.get(CorrelationIDFilter.CORRELATION_ID_KEY));
            HttpEntity<Object> entity = new HttpEntity<Object>(requestBody, headers);
            response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            HttpStatus statusCode = response.getStatusCode();
            log.info("Response status code :" + statusCode);
        } catch (RestClientException e) {
            log.error(e);
            throw new TFMicroServiceException(TFMicroServicesConstant.MS_001_ERROR_CODE,
                    TFMicroServicesConstant.MS_001_ERROR_MESSAGE, e.getMessage(), e);
        }
        String responseBody = response.getBody();
        log.info("Response : " + responseBody);
        return responseBody;
    }

}