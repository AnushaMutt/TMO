#!/bin/bash
QUERY_NAME="inquiry-verizon"
APP_SHORT_NAME="$QUERY_NAME"
echo "$APP_SHORT_NAME"
ps -ef | grep java | grep -v grep  | grep "D${APP_SHORT_NAME} " | awk ' { print $0 } ' | xargs kill -9
sleep 10
JAVA_HOME=/opt/bea/bea1033/jdk1.8.0_73
echo "Here "
APP_HOME=`pwd`
HOME=`cd "$APP_HOME/.." ; pwd`
JAVA_OPTS="-D$APP_SHORT_NAME -D$APP_HOME"
JAVA_MEM="-Xms128m -Xmx512m"
CLASSPATH="$APP_HOME/bin/inquiry-verizon-1.0.jar"
echo "$CLASSPATH"
CONFIG_PATH="$APP_HOME/config/"
 
nohup $JAVA_HOME/bin/java $JAVA_OPTS $JAVA_MEM  -jar -Dserver.port=8904  $CLASSPATH --spring.config.location=$CONFIG_PATH > nohup_$QUERY_NAME.out 2>&1 &
 
echo "$APP_SHORT_NAME Started ....."