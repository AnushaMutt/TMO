package com.tracfone.inquiry.tmobile.config;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
public class AppConfigTest {

    @Spy
    private AppConfig appConfig;

    @Test
    public void testServletRegistrationBean() {
        assertNotNull(appConfig.servletRegistrationBean());
    }
}