package com.tracfone.inquiry.tmobile.helper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = {"tmobile.nextgen.wholesale.service.url=url", "tmobile.nextgen.wholesale.popToken=popToken",
        "tmobile.nextgen.wholesale.key=key", "tmobile.nextgen.wholesale.secret=secret",})
public class PropertyHelperTest {

    @Value("${tmobile.nextgen.wholesale.service.url}")
    private String serviceURL;

    @Value("${tmobile.nextgen.wholesale.popToken}")
    private String popToken;

    @Value("${tmobile.nextgen.wholesale.key}")
    private String key;

    @Value("${tmobile.nextgen.wholesale.secret}")
    private String secret;
    @Spy
    private PropertyHelper propertyHelper;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(propertyHelper, "serviceURL", serviceURL);
        ReflectionTestUtils.setField(propertyHelper, "popToken", popToken);
        ReflectionTestUtils.setField(propertyHelper, "key", key);
        ReflectionTestUtils.setField(propertyHelper, "secret", secret);
    }

    @Test
    public void testSettersAndGetters() {
        propertyHelper.setServiceURL(serviceURL);
        propertyHelper.setSecret(secret);
        propertyHelper.setPopToken(popToken);
        propertyHelper.setKey(key);
        assertEquals(serviceURL, PropertyHelper.getServiceURL());
        assertEquals(popToken, PropertyHelper.getPopToken());
        assertEquals(key, PropertyHelper.getKey());
        assertEquals(secret, PropertyHelper.getSecret());
    }
}