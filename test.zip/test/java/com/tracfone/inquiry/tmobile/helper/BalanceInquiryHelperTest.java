package com.tracfone.inquiry.tmobile.helper;

import com.tracfone.igate.cxf.clients.AccountIDTypeV3;
import com.tracfone.igate.cxf.clients.BaseProductTypeV4;
import com.tracfone.igate.cxf.clients.HeaderResponseTypeV3;
import com.tracfone.igate.cxf.clients.LimitTypeV3;
import com.tracfone.igate.cxf.clients.ProductRenewalInfoTypeV3;
import com.tracfone.igate.cxf.clients.ProductTypeV3;
import com.tracfone.igate.cxf.clients.QueryAccountRequest;
import com.tracfone.igate.cxf.clients.QueryAccountResponse;
import com.tracfone.igate.cxf.clients.QueryInfoRequestV3;
import com.tracfone.igate.cxf.clients.QueryInfoResponseTypeV3;
import com.tracfone.igate.cxf.clients.QueryInfoResponseV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsRequestV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsResponseTypeV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsResponseV3;
import com.tracfone.igate.cxf.clients.ResultTypeV3;
import com.tracfone.igate.cxf.clients.ThresholdsTypeV3;
import com.tracfone.igate.cxf.clients.UsageTypeV3;
import com.tracfone.igate.cxf.clients.WPSTypeV3;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.tmobile.constant.TmobileConstant;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
public class BalanceInquiryHelperTest {
    private static final String MIN = "7862124910";
    private static final String SIM = "8901260892131386845";
    private static final String SUCCESS = "SUCCESS";
    private static final String BRAND = "TRACFONE";
    public static final String SAMPLE = "SAMPLE";
    private static final String ACCOUNT_NUMBER = "10422858915";

    @Spy
    private BalanceInquiryHelper balanceInquiryHelper;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testPopulateQuerySubscriberDetailsRequestV3ForMin() {
        QuerySubscriberDetailsRequestV3 querySubscriberDetailsRequestV3 = balanceInquiryHelper.populateQuerySubscriberDetailsRequestV3ForMin("7862124910", SAMPLE);
        Assert.assertEquals(TmobileConstant.CALLBACK_URL, querySubscriberDetailsRequestV3.getHeader().getCallBackLocation());
    }

    @Test
    public void testPopulateQuerySubscriberDetailsRequestV3ForICCID() {
        QuerySubscriberDetailsRequestV3 querySubscriberDetailsRequestV3 = balanceInquiryHelper.populateQuerySubscriberDetailsRequestV3ForIccid("8901260892131386845", SAMPLE);
        Assert.assertEquals(TmobileConstant.CALLBACK_URL, querySubscriberDetailsRequestV3.getHeader().getCallBackLocation());
    }

    @Test
    public void testPopulateTFOneCarrierSubscriber_whenUnitIsGBMB() {
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = getQuerySubscriberDetailsResponseV3(true, false, false, false);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateTFOneCarrierSubscriber(querySubscriberDetailsResponseV3);
        Assert.assertEquals(SUCCESS, tfOneCarrierSubscriber.getStatus());

    }

    @Test
    public void testPopulateTFOneCarrierSubscriber_whenUnitIsKBB() {
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = getQuerySubscriberDetailsResponseV3(false, true, false, false);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateTFOneCarrierSubscriber(querySubscriberDetailsResponseV3);
        Assert.assertEquals(SUCCESS, tfOneCarrierSubscriber.getStatus());

    }

    @Test
    public void testPopulateTFOneCarrierSubscriber_whenUnitIsDollar() {
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = getQuerySubscriberDetailsResponseV3(false, false, true, false);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateTFOneCarrierSubscriber(querySubscriberDetailsResponseV3);
        Assert.assertEquals(SUCCESS, tfOneCarrierSubscriber.getStatus());

    }

    @Test
    public void testPopulateTFOneCarrierSubscriber_whenUnitIsOther() {
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = getQuerySubscriberDetailsResponseV3(false, false, false, true);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateTFOneCarrierSubscriber(querySubscriberDetailsResponseV3);
        Assert.assertEquals(SUCCESS, tfOneCarrierSubscriber.getStatus());

    }

    @Test
    public void testPopulateTFOneCarrierSubscriberWithBuckets() {
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = getQuerySubscriberDetailsResponseV3(false, false, true, false);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateTFOneCarrierSubscriber(querySubscriberDetailsResponseV3);
        tfOneCarrierSubscriber = balanceInquiryHelper.populateTFOneCarrierSubscriberWithBuckets(querySubscriberDetailsResponseV3, tfOneCarrierSubscriber);
        Assert.assertEquals(SUCCESS, tfOneCarrierSubscriber.getStatus());

    }

    @Test
    public void testPopulateTFOneCarrierSubscriber_whenResultNot100() {
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        List<QuerySubscriberDetailsResponseV3.Body.Response> responses = new ArrayList<>();
        QuerySubscriberDetailsResponseV3.Body body = new QuerySubscriberDetailsResponseV3.Body();
        QuerySubscriberDetailsResponseV3.Body.Response response = new QuerySubscriberDetailsResponseV3.Body.Response();
        response.setPartnerTransactionID("12345");
        QuerySubscriberDetailsResponseTypeV3 querySubscriberDetailsResponseTypeV3 = new QuerySubscriberDetailsResponseTypeV3();
        querySubscriberDetailsResponseTypeV3.setICCID(SIM);
        querySubscriberDetailsResponseTypeV3.setMSISDN(MIN);
        querySubscriberDetailsResponseTypeV3.setBrand(BRAND);
        List<ResultTypeV3> resultTypeV3s = new ArrayList();
        ResultTypeV3 resultTypeV3 = new ResultTypeV3();
        resultTypeV3.setStatus(SUCCESS);
        resultTypeV3.setResult("400");
        resultTypeV3s.add(resultTypeV3);
        querySubscriberDetailsResponseTypeV3.getResult().addAll(resultTypeV3s);
        response.setQuerySubscriberDetails(querySubscriberDetailsResponseTypeV3);
        responses.add(response);
        body.setResponseCount(1);
        body.getResponse().addAll(responses);
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = new QuerySubscriberDetailsResponseV3();
        querySubscriberDetailsResponseV3.setHeaderResponse(headerResponseTypeV3);
        querySubscriberDetailsResponseV3.setBody(body);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateTFOneCarrierSubscriber(querySubscriberDetailsResponseV3);
        Assert.assertEquals(SUCCESS, tfOneCarrierSubscriber.getStatus());
    }

    private QuerySubscriberDetailsResponseV3 getQuerySubscriberDetailsResponseV3(boolean gbMB, boolean kbb, boolean doller, boolean other) {
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        List<QuerySubscriberDetailsResponseV3.Body.Response> responses = new ArrayList<>();
        QuerySubscriberDetailsResponseV3.Body body = new QuerySubscriberDetailsResponseV3.Body();
        QuerySubscriberDetailsResponseV3.Body.Response response = new QuerySubscriberDetailsResponseV3.Body.Response();
        response.setPartnerTransactionID("12345");
        QuerySubscriberDetailsResponseTypeV3 querySubscriberDetailsResponseTypeV3 = new QuerySubscriberDetailsResponseTypeV3();
        querySubscriberDetailsResponseTypeV3.setICCID(SIM);
        querySubscriberDetailsResponseTypeV3.setMSISDN(MIN);
        querySubscriberDetailsResponseTypeV3.setBrand(BRAND);
        List<ResultTypeV3> resultTypeV3s = new ArrayList();
        ResultTypeV3 resultTypeV3 = new ResultTypeV3();
        resultTypeV3.setStatus(SUCCESS);
        resultTypeV3.setResult("100");
        resultTypeV3s.add(resultTypeV3);
        querySubscriberDetailsResponseTypeV3.getResult().addAll(resultTypeV3s);
        BaseProductTypeV4 baseProductTypeV4 = new BaseProductTypeV4();
        List<ProductTypeV3> products = new ArrayList<>();
        ProductTypeV3 productTypeV3 = new ProductTypeV3();
        productTypeV3.setAction("A");
        productTypeV3.setResetUsage(true);
        productTypeV3.setDescription(SAMPLE);
        ProductTypeV3.ProductID productID = new ProductTypeV3.ProductID();
        productID.setIsBaseProduct(true);
        productID.setValue("1234");
        productTypeV3.setProductID(productID);
        ProductRenewalInfoTypeV3 renewalType = new ProductRenewalInfoTypeV3();
        renewalType.setAutoRenew(true);
        productTypeV3.setRenewalInfo(renewalType);
        List<UsageTypeV3> usageList = new ArrayList<>();
        UsageTypeV3 usageTypeV3 = new UsageTypeV3();
        usageTypeV3.setStatus(SUCCESS);
        usageTypeV3.setCurrentBehavior(SAMPLE);
        usageTypeV3.setUsageLevel("1");
        if (gbMB) {
            setUnitsForGBMB(usageTypeV3);
        } else if (kbb) {
            setUnitsForKBB(usageTypeV3);
        } else if (doller) {
            setUnitsForDoller(usageTypeV3);
        } else {
            setUnitsForOther(usageTypeV3);
        }
        LimitTypeV3 limitTypeV3 = new LimitTypeV3();
        limitTypeV3.setCategory(SAMPLE);
        limitTypeV3.setType(TmobileConstant.TETHER);
        List<ThresholdsTypeV3> tiers = new ArrayList<>();
        ThresholdsTypeV3 thresholdsTypeV3 = new ThresholdsTypeV3();
        thresholdsTypeV3.setAction(SAMPLE);
        thresholdsTypeV3.setBehavior(SAMPLE);
        thresholdsTypeV3.setThresholdType(SAMPLE);
        ThresholdsTypeV3.ThresholdValue thresholdValue = new ThresholdsTypeV3.ThresholdValue();
        thresholdValue.setValue(SAMPLE);
        thresholdsTypeV3.setThresholdValue(thresholdValue);
        tiers.add(thresholdsTypeV3);
        LimitTypeV3.BucketValue bucketValue = new LimitTypeV3.BucketValue();
        bucketValue.setValue(SAMPLE);
        bucketValue.setUnit("GB");
        limitTypeV3.setBucketValue(bucketValue);
        limitTypeV3.getThresholds().addAll(tiers);
        usageTypeV3.setLimit(limitTypeV3);

        usageList.add(usageTypeV3);
        productTypeV3.getUsage().addAll(usageList);
        products.add(productTypeV3);
        baseProductTypeV4.setAction("A");
        baseProductTypeV4.setBaseProductID("12345");
        baseProductTypeV4.setResetUsage(true);
        baseProductTypeV4.setBaseProductID("1");
        baseProductTypeV4.getProduct().addAll(products);
        WPSTypeV3 wpsTypeV3 = new WPSTypeV3();
        wpsTypeV3.setValue("10770022");
        baseProductTypeV4.getWPS().add(wpsTypeV3);
        querySubscriberDetailsResponseTypeV3.setBaseProduct(baseProductTypeV4);
        response.setQuerySubscriberDetails(querySubscriberDetailsResponseTypeV3);
        responses.add(response);
        body.setResponseCount(1);
        body.getResponse().addAll(responses);
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = new QuerySubscriberDetailsResponseV3();
        querySubscriberDetailsResponseV3.setHeaderResponse(headerResponseTypeV3);
        querySubscriberDetailsResponseV3.setBody(body);
        return querySubscriberDetailsResponseV3;
    }

    private void setUnitsForGBMB(UsageTypeV3 usageTypeV3) {
        UsageTypeV3.Used used = new UsageTypeV3.Used();
        used.setUnit("GB");
        used.setValue("1024");
        usageTypeV3.setUsed(used);
        UsageTypeV3.Remaining remaining = new UsageTypeV3.Remaining();
        remaining.setUnit("MB");
        remaining.setValue("500");
        usageTypeV3.setRemaining(remaining);
    }

    private void setUnitsForKBB(UsageTypeV3 usageTypeV3) {
        UsageTypeV3.Used used = new UsageTypeV3.Used();
        used.setUnit("KB");
        used.setValue("1024");
        usageTypeV3.setUsed(used);
        UsageTypeV3.Remaining remaining = new UsageTypeV3.Remaining();
        remaining.setUnit("B");
        remaining.setValue("500");
        usageTypeV3.setRemaining(remaining);
    }

    private void setUnitsForDoller(UsageTypeV3 usageTypeV3) {
        UsageTypeV3.Used used = new UsageTypeV3.Used();
        used.setUnit("$");
        used.setValue("1024");
        usageTypeV3.setUsed(used);
        UsageTypeV3.Remaining remaining = new UsageTypeV3.Remaining();
        remaining.setUnit("CENT");
        remaining.setValue("500");
        usageTypeV3.setRemaining(remaining);
    }

    private void setUnitsForOther(UsageTypeV3 usageTypeV3) {
        UsageTypeV3.Used used = new UsageTypeV3.Used();
        used.setUnit(SAMPLE);
        used.setValue("1024");
        usageTypeV3.setUsed(used);
        UsageTypeV3.Remaining remaining = new UsageTypeV3.Remaining();
        remaining.setUnit("CENTS");
        remaining.setValue("500");
        usageTypeV3.setRemaining(remaining);
    }

    @Test
    public void testPopulateSimValidationRequestV3ForIccid() {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        QueryInfoRequestV3 queryInfoRequestV3 = balanceInquiryHelper.populateSimValidationRequestV3ForIccid("8901260892131386845");
        Assert.assertEquals(TmobileConstant.CALLBACK_URL, queryInfoRequestV3.getHeader().getCallBackLocation());
    }

    @Test
    public void testPopulateQueryInfoResponseTypeV3() {
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        List<QueryInfoResponseV3.Body.Response> responses = new ArrayList<>();
        QueryInfoResponseV3.Body body = new QueryInfoResponseV3.Body();
        QueryInfoResponseV3.Body.Response response = new QueryInfoResponseV3.Body.Response();
        response.setPartnerTransactionID("12345");
        response.setPartnerID(138);
        responses.add(response);
        body.setResponseCount(1);
        body.getResponse().addAll(responses);
        QueryInfoResponseV3 queryInfoResponseV3 = new QueryInfoResponseV3();
        List<QueryInfoResponseTypeV3> queryInfoList = responses.get(0).getQueryInfo();
        QueryInfoResponseTypeV3 carrierResponse = new QueryInfoResponseTypeV3();
        carrierResponse.setICCID("SIM");
        carrierResponse.setStatus("STATUS");
        queryInfoList.add(carrierResponse);
        queryInfoResponseV3.setHeaderResponse(headerResponseTypeV3);
        queryInfoResponseV3.setBody(body);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateQueryInfoResponseTypeV3(queryInfoResponseV3);
        Assert.assertEquals("STATUS", tfOneCarrierSubscriber.getStatus());
    }

    @Test
    public void testPopulateInquireByAccountNum() {
        QueryAccountRequest queryAccountRequest = balanceInquiryHelper.populateQueryAccountRequest(ACCOUNT_NUMBER);
        Assert.assertEquals(TmobileConstant.CALLBACK_URL, queryAccountRequest.getHeader().getCallBackLocation());
    }

    @Test
    public void testPopulateQueryAccountResponse() {
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        List<QueryAccountResponse.Body.Response> responses = new ArrayList<>();
        QueryAccountResponse.Body body = new QueryAccountResponse.Body();
        QueryAccountResponse.Body.Response response = new QueryAccountResponse.Body.Response();
        response.setPartnerTransactionID("12345");
        response.setPartnerID(138);
        responses.add(response);
        body.setResponse(response);
        QueryAccountResponse.Body.Response.QueryAccount queryAccount = new QueryAccountResponse.Body.Response.QueryAccount();
        QueryAccountResponse.Body.Response.QueryAccount.AccountInfo info = new QueryAccountResponse.Body.Response.QueryAccount.AccountInfo();
        AccountIDTypeV3 acc = new AccountIDTypeV3();
        acc.setValue(ACCOUNT_NUMBER);
        acc.setIsMultiline(true);
        info.setAccountID(acc);
        queryAccount.setAccountInfo(info);
        body.getResponse().getQueryAccount().add(queryAccount);
        QueryAccountResponse queryAccountResponse = new QueryAccountResponse();
        List<QueryAccountResponse.Body.Response.QueryAccount> queryAccountList = responses.get(0).getQueryAccount();
        QueryAccountResponse.Body.Response.QueryAccount carrierResponse = new QueryAccountResponse.Body.Response.QueryAccount();
        carrierResponse.setAccountInfo(info);
        carrierResponse.setStatus("SUCCESS");
        queryAccountList.add(carrierResponse);
        queryAccountResponse.setHeaderResponse(headerResponseTypeV3);
        queryAccountResponse.setBody(body);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = balanceInquiryHelper.populateQueryAccountResponse(queryAccountResponse);
        Assert.assertEquals("SUCCESS", tfOneCarrierSubscriber.getStatus());
    }

    @Test
    public void testPopulateSimValidationRequestV3ForIccid2() {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        QueryInfoRequestV3 queryInfoRequestV3 = balanceInquiryHelper.populateQuerySubscriberDetailsRequestV3ForIccid2("8901260892131386845");
        Assert.assertEquals(TmobileConstant.CALLBACK_URL, queryInfoRequestV3.getHeader().getCallBackLocation());
    }

}