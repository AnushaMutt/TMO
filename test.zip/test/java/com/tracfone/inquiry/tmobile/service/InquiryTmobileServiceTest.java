package com.tracfone.inquiry.tmobile.service;

import com.tracfone.igate.cxf.clients.Fault_Exception;
import com.tracfone.igate.cxf.clients.HeaderResponseTypeV3;
import com.tracfone.igate.cxf.clients.QueryAccountRequest;
import com.tracfone.igate.cxf.clients.QueryAccountResponse;
import com.tracfone.igate.cxf.clients.QueryInfoRequestV3;
import com.tracfone.igate.cxf.clients.QueryInfoResponseV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsRequestV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsResponseV3;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.tmobile.helper.BalanceInquiryHelper;
import com.tracfone.inquiry.tmobile.helper.PropertyHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

@RunWith(SpringRunner.class)
public class InquiryTmobileServiceTest {
    private static final String MIN = "7862124910";
    private static final String SIM = "8901260892131386845";
    private static final String SAMPLE = "SAMPLE";
    private static final String ACCOUNT_NUMBER = "10422858915";

    @Spy
    private InquiryTmobileServiceImpl tMobileBalanceInquiryService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        setPropertyHelper();
    }

    private static void setPropertyHelper() {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setServiceURL(SAMPLE);
        propertyHelper.setSecret(SAMPLE);
        propertyHelper.setPopToken(SAMPLE);
        propertyHelper.setKey(SAMPLE);
    }

    @Test
    public void testBalanceInquiryByMin() throws Fault_Exception {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setMin(MIN);
        doReturn(tfOneCarrierSubscriber).when(tMobileBalanceInquiryService).balanceInquiry(any(QuerySubscriberDetailsRequestV3.class), any(TFOneCarrierSubscriber.class));
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        QuerySubscriberDetailsResponseV3.Body body = new QuerySubscriberDetailsResponseV3.Body();
        body.setResponseCount(1);
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = new QuerySubscriberDetailsResponseV3();
        querySubscriberDetailsResponseV3.setHeaderResponse(headerResponseTypeV3);
        querySubscriberDetailsResponseV3.setBody(body);
        doReturn(querySubscriberDetailsResponseV3).when(tMobileBalanceInquiryService).getResponse(any());
        TFOneCarrierSubscriber response = tMobileBalanceInquiryService.balanceInquiryByMin(MIN);
        assertEquals(tfOneCarrierSubscriber.getMin(), response.getMin());
    }

    @Test
    public void testBalanceInquiryByICCID() throws Fault_Exception {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setSim(SIM);
        doReturn(tfOneCarrierSubscriber).when(tMobileBalanceInquiryService).balanceInquiry(any(QuerySubscriberDetailsRequestV3.class), any(TFOneCarrierSubscriber.class));
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        QuerySubscriberDetailsResponseV3.Body body = new QuerySubscriberDetailsResponseV3.Body();
        body.setResponseCount(1);
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = new QuerySubscriberDetailsResponseV3();
        querySubscriberDetailsResponseV3.setHeaderResponse(headerResponseTypeV3);
        querySubscriberDetailsResponseV3.setBody(body);
        doReturn(querySubscriberDetailsResponseV3).when(tMobileBalanceInquiryService).getResponse(any());
        TFOneCarrierSubscriber response = tMobileBalanceInquiryService.balanceInquiryByIccid(SIM);
        assertEquals(tfOneCarrierSubscriber.getSim(), response.getSim());
    }

    @Test
    public void testBalanceInquiryByICCID_whenBalanceInquiryThrowsException() {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setMin(MIN);
        try {
            doThrow(Fault_Exception.class).when(tMobileBalanceInquiryService).getResponse(any());
            tMobileBalanceInquiryService.balanceInquiryByIccid(MIN);
        } catch (Fault_Exception | RuntimeException e) {
            assertTrue(e instanceof Exception);
        }
    }

    @Test
    public void testBalanceInquiryByICCID_whenBalanceInquiry() throws Fault_Exception {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        QuerySubscriberDetailsResponseV3.Body body = new QuerySubscriberDetailsResponseV3.Body();
        body.setResponseCount(1);
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = new QuerySubscriberDetailsResponseV3();
        querySubscriberDetailsResponseV3.setHeaderResponse(headerResponseTypeV3);
        querySubscriberDetailsResponseV3.setBody(body);
        doReturn(querySubscriberDetailsResponseV3).when(tMobileBalanceInquiryService).getResponse(any());
        TFOneCarrierSubscriber response = tMobileBalanceInquiryService.balanceInquiryByIccid(SIM);
        assertEquals("SUCCESS", response.getStatus());
    }

    @Test
    public void testBalanceInquiry_whenException() {
        try {
            QuerySubscriberDetailsRequestV3 request = BalanceInquiryHelper
                    .populateQuerySubscriberDetailsRequestV3ForIccid(SIM, SAMPLE);
            TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
            tfOneCarrierSubscriber.setSim(SIM);
            tMobileBalanceInquiryService.balanceInquiry(request, tfOneCarrierSubscriber);
        } catch (RuntimeException e) {
            assertTrue(e instanceof Exception);
        }
    }

    @Test
    public void testValidateSimByIccid() throws Fault_Exception {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setSim(SIM);
        doReturn(tfOneCarrierSubscriber).when(tMobileBalanceInquiryService).validateSim(any(QueryInfoRequestV3.class));
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        QueryInfoResponseV3.Body body = new QueryInfoResponseV3.Body();
        body.setResponseCount(1);
        QueryInfoResponseV3 queryInfoResponseV3 = new QueryInfoResponseV3();
        queryInfoResponseV3.setHeaderResponse(headerResponseTypeV3);
        queryInfoResponseV3.setBody(body);
        doReturn(queryInfoResponseV3).when(tMobileBalanceInquiryService).getSimValidateResponse(any());
        TFOneCarrierSubscriber response = tMobileBalanceInquiryService.validateSimByIccid(SIM);
        assertEquals(tfOneCarrierSubscriber.getSim(), response.getSim());
        assertEquals("SUCCESS", response.getStatus());
    }

    @Test
    public void testValidateSimByIccid_whenException() {
        try {
            QueryInfoRequestV3 request = BalanceInquiryHelper
                    .populateSimValidationRequestV3ForIccid(SIM);
            TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
            tfOneCarrierSubscriber.setSim(SIM);
            tMobileBalanceInquiryService.validateSim(request);
        } catch (RuntimeException e) {
            assertTrue(e instanceof Exception);
        }
    }

    @Test
    public void testInquireByAccountNum() throws Fault_Exception {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        doReturn(tfOneCarrierSubscriber).when(tMobileBalanceInquiryService).inquireAccount(any(QueryAccountRequest.class));
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        QueryAccountResponse.Body body = new QueryAccountResponse.Body();
        QueryAccountResponse queryAccountResponse = new QueryAccountResponse();
        queryAccountResponse.setHeaderResponse(headerResponseTypeV3);
        queryAccountResponse.setBody(body);
        doReturn(queryAccountResponse).when(tMobileBalanceInquiryService).getAccountResponse(any());
        TFOneCarrierSubscriber response = tMobileBalanceInquiryService.inquireByAccountNum(ACCOUNT_NUMBER);
        assertEquals(tfOneCarrierSubscriber.getSim(), response.getSim());
        assertEquals("SUCCESS", response.getStatus());
    }

    @Test
    public void testinquireByAccountNum_whenException() {
        try {
            QueryAccountRequest request = BalanceInquiryHelper
                    .populateQueryAccountRequest(ACCOUNT_NUMBER);
            tMobileBalanceInquiryService.inquireAccount(request);
        } catch (RuntimeException e) {
            assertTrue(e instanceof Exception);
        }
    }

    @Test
    public void testValidateSimByIccid2() throws Fault_Exception {
        PropertyHelper propertyHelper = new PropertyHelper();
        propertyHelper.setPartnerId(138);
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setSim(SIM);
        doReturn(tfOneCarrierSubscriber).when(tMobileBalanceInquiryService).validateSim2(any(QueryInfoRequestV3.class));
        HeaderResponseTypeV3 headerResponseTypeV3 = new HeaderResponseTypeV3();
        headerResponseTypeV3.setFileName(SAMPLE);
        headerResponseTypeV3.setSenderID(123);
        QueryInfoResponseV3.Body body = new QueryInfoResponseV3.Body();
        body.setResponseCount(1);
        QueryInfoResponseV3 queryInfoResponseV3 = new QueryInfoResponseV3();
        queryInfoResponseV3.setHeaderResponse(headerResponseTypeV3);
        queryInfoResponseV3.setBody(body);
        doReturn("queryInfoResponseV3").when(tMobileBalanceInquiryService).getSim2ValidateResponse(any());
        TFOneCarrierSubscriber response = tMobileBalanceInquiryService.validateSimByIccid2(SIM);
        assertEquals(tfOneCarrierSubscriber.getSim(), response.getSim());
        assertEquals("SUCCESS", response.getStatus());
    }

    @Test
    public void testValidateSimByIccid2_whenException() {
        try {
            QueryInfoRequestV3 request = BalanceInquiryHelper
                    .populateSimValidationRequestV3ForIccid(SIM);
            TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
            tfOneCarrierSubscriber.setSim(SIM);
            tMobileBalanceInquiryService.validateSim2(request);
        } catch (RuntimeException e) {
            assertTrue(e instanceof Exception);
        }
    }

}