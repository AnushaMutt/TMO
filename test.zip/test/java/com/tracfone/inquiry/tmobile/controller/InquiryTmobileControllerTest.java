package com.tracfone.inquiry.tmobile.controller;

import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.tmobile.service.InquiryTmobileService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class InquiryTmobileControllerTest {
    private static final String MIN = "7862124910";
    private static final String SIM = "8901260892131386845";
    private static final String ACCOUNT_NUMBER = "10422858915";

    @MockBean
    private InquiryTmobileService tmobileBalanceInquiryService;
    @Spy
    private InquiryTmobileController tMobileBalanceInquiryController;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(tMobileBalanceInquiryController, "tmobileBalanceInquiryService", tmobileBalanceInquiryService);
    }

    @Test
    public void testBalanceInquiryByMin() {
        TFOneCarrierSubscriber expectedResponse = populateResponse();
        when(tmobileBalanceInquiryService.balanceInquiryByMin(any())).thenReturn(expectedResponse);
        tMobileBalanceInquiryController.balanceInquiryByMin(MIN);
        verify(tmobileBalanceInquiryService, times(1)).balanceInquiryByMin(any());
    }

    @Test
    public void testBalanceInquiryByMin_whenException() {
        doThrow(TFMicroServiceException.class).when(tmobileBalanceInquiryService).balanceInquiryByMin(any());
        tMobileBalanceInquiryController.balanceInquiryByMin(MIN);
        verify(tmobileBalanceInquiryService, times(1)).balanceInquiryByMin(any());
    }

    @Test
    public void testBalanceInquiryBySim() {
        TFOneCarrierSubscriber expectedResponse = populateResponse();
        when(tmobileBalanceInquiryService.balanceInquiryByIccid(any())).thenReturn(expectedResponse);
        tMobileBalanceInquiryController.balanceInquiryBySim(SIM);
        verify(tmobileBalanceInquiryService, times(1)).balanceInquiryByIccid(any());
    }

    @Test
    public void testBalanceInquiryBySim_whenException() {
        doThrow(TFMicroServiceException.class).when(tmobileBalanceInquiryService).balanceInquiryByIccid(any());
        tMobileBalanceInquiryController.balanceInquiryBySim(SIM);
        verify(tmobileBalanceInquiryService, times(1)).balanceInquiryByIccid(any());
    }

    private TFOneCarrierSubscriber populateResponse() {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setMin(MIN);
        tfOneCarrierSubscriber.setSim(SIM);
        tfOneCarrierSubscriber.setErrorCode("200");
        return tfOneCarrierSubscriber;
    }

    @Test
    public void testValidateSim() {
        TFOneCarrierSubscriber expectedResponse = populateResponse();
        when(tmobileBalanceInquiryService.validateSimByIccid(any())).thenReturn(expectedResponse);
        tMobileBalanceInquiryController.validateSim(SIM);
        verify(tmobileBalanceInquiryService, times(1)).validateSimByIccid(any());
    }

    @Test
    public void testValidateSim_whenException() {
        doThrow(TFMicroServiceException.class).when(tmobileBalanceInquiryService).validateSimByIccid(any());
        tMobileBalanceInquiryController.validateSim(SIM);
        verify(tmobileBalanceInquiryService, times(1)).validateSimByIccid(any());
    }

    @Test
    public void testInquireByAccountNum() {
        TFOneCarrierSubscriber expectedResponse = populateResponse();
        when(tmobileBalanceInquiryService.inquireByAccountNum(any())).thenReturn(expectedResponse);
        tMobileBalanceInquiryController.inquireByAccountNum(ACCOUNT_NUMBER);
        verify(tmobileBalanceInquiryService, times(1)).inquireByAccountNum(any());
    }

    @Test
    public void testInquireByAccountNum_whenException() {
        doThrow(TFMicroServiceException.class).when(tmobileBalanceInquiryService).inquireByAccountNum(any());
        tMobileBalanceInquiryController.inquireByAccountNum(ACCOUNT_NUMBER);
        verify(tmobileBalanceInquiryService, times(1)).inquireByAccountNum(any());
    }

    @Test
    public void testValidateSim2() {
        TFOneCarrierSubscriber expectedResponse = populateResponse();
        when(tmobileBalanceInquiryService.validateSimByIccid2(any())).thenReturn(expectedResponse);
        tMobileBalanceInquiryController.validateSim2(SIM);
        verify(tmobileBalanceInquiryService, times(1)).validateSimByIccid2(any());
    }

    @Test
    public void testValidateSim_2whenException() {
        doThrow(TFMicroServiceException.class).when(tmobileBalanceInquiryService).validateSimByIccid2(any());
        tMobileBalanceInquiryController.validateSim2(SIM);
        verify(tmobileBalanceInquiryService, times(1)).validateSimByIccid2(any());
    }


}