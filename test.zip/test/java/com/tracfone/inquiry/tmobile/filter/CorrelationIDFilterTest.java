/**
 *
 */
package com.tracfone.inquiry.tmobile.filter;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @author tracfoneid@tracfone.com
 *
 */
public class CorrelationIDFilterTest {

    private HttpServletRequest request;
    private HttpServletResponse response;
    private FilterChain filterChain;
    private CorrelationIDFilter filter;

    @Before
    public void init() {
        request = mock(HttpServletRequest.class);
        response = mock(HttpServletResponse.class);
        filterChain = mock(FilterChain.class);
        filter = new CorrelationIDFilter();
    }

    @After
    public void tearDown() {
        request = null;
        response = null;
        filterChain = null;
        filter = null;
    }


    /**
     * Test method for {@link com.tracfone.inquiry.tmobile.filter.CorrelationIDFilter#doFilterInternal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, javax.servlet.FilterChain)}.
     * @throws ServletException
     * @throws IOException
     */
    @Test
    public void testDoFilterInternalHttpServletRequestHttpServletResponseFilterChain() throws IOException, ServletException {

        when(request.getHeader(CorrelationIDFilter.CORRELATION_ID_KEY)).thenReturn("1");

        filter.doFilterInternal(request, response, filterChain);

        verify(response).addHeader(CorrelationIDFilter.CORRELATION_ID_KEY, "1");
        verify(filterChain).doFilter(request, response);

    }

    @Test
    public void testEmptyCorrelation() throws ServletException, IOException {
        when(request.getHeader(CorrelationIDFilter.CORRELATION_ID_KEY)).thenReturn(null);

        filter.doFilterInternal(request, response, filterChain);

        verify(response).addHeader(eq(CorrelationIDFilter.CORRELATION_ID_KEY), anyString());
        verify(filterChain).doFilter(request, response);
    }

    @Test
    public void testDoFilterInternal() throws Exception {
        Class clazz = CorrelationIDFilter.class;
        Method method = clazz.getDeclaredMethod("doFilterInternal", new Class[]{HttpServletRequest.class, HttpServletResponse.class, FilterChain.class});
        method.setAccessible(true);
        filter.doFilterInternal(request, response, filterChain);
        assertEquals(true, method.isAccessible());
    }

    @Test
    public void testDoFilterInterna_whenException() throws Exception {
        Class clazz = CorrelationIDFilter.class;
        Method method = clazz.getDeclaredMethod("doFilterInternal", new Class[]{HttpServletRequest.class, HttpServletResponse.class, FilterChain.class});
        method.setAccessible(true);
        filter.doFilterInternal(request, response, null);
        assertEquals(true, method.isAccessible());
    }

    @Test
    public void testIsAsyncDispatch() throws Exception {
        Class clazz = CorrelationIDFilter.class;
        Method method = clazz.getDeclaredMethod("isAsyncDispatch", new Class[]{HttpServletRequest.class});
        method.setAccessible(true);
        assertEquals(false, filter.isAsyncDispatch(request));
    }

    @Test
    public void testShouldNotFilterErrorDispatch() throws Exception {
        Class clazz = CorrelationIDFilter.class;
        Method method = clazz.getDeclaredMethod("shouldNotFilterErrorDispatch");
        method.setAccessible(true);
        assertEquals(false, filter.shouldNotFilterErrorDispatch());
    }
}
