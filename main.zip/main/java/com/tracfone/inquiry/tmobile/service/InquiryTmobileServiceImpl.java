package com.tracfone.inquiry.tmobile.service;

import com.tracfone.igate.cxf.clients.*;
import com.tracfone.inquiry.common.constant.TFMicroServicesConstant;
import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.common.util.JAXBUtil;
import com.tracfone.inquiry.tmobile.helper.BalanceInquiryHelper;
import com.tracfone.inquiry.tmobile.helper.PropertyHelper;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.QUERY_SUBSCRIBER_USAGE;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.RESPONSE;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.SUBSCRIBER_INQUIRY;

@Log4j2
@Service
public class InquiryTmobileServiceImpl implements InquiryTmobileService {

    public TFOneCarrierSubscriber balanceInquiryByMin(String min) {
        QuerySubscriberDetailsRequestV3 request = BalanceInquiryHelper
                .populateQuerySubscriberDetailsRequestV3ForMin(min, SUBSCRIBER_INQUIRY);
        TFOneCarrierSubscriber subscriber = balanceInquiry(request, null);
        request = BalanceInquiryHelper
                .populateQuerySubscriberDetailsRequestV3ForMin(min, QUERY_SUBSCRIBER_USAGE);
        return balanceInquiry(request, subscriber);
    }

    public TFOneCarrierSubscriber balanceInquiryByIccid(String iccid) {
        QuerySubscriberDetailsRequestV3 request = BalanceInquiryHelper
                .populateQuerySubscriberDetailsRequestV3ForIccid(iccid, SUBSCRIBER_INQUIRY);
        TFOneCarrierSubscriber subscriber = balanceInquiry(request, null);
        request = BalanceInquiryHelper
                .populateQuerySubscriberDetailsRequestV3ForIccid(iccid, QUERY_SUBSCRIBER_USAGE);
        return balanceInquiry(request, subscriber);
    }

    @Override
    public TFOneCarrierSubscriber balanceInquiry(QuerySubscriberDetailsRequestV3 request, TFOneCarrierSubscriber subscriber) {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = null;
        log.info("request subscriber " + subscriber);
        if (subscriber == null || StringUtils.isEmpty(subscriber.getCarrierErrorMessage())) {
            QuerySubscriberDetailsResponseV3 response = null;
            try {
                response = getResponse(request);
                log.debug(RESPONSE + response);
                JAXBUtil.marshalObject(response, QuerySubscriberDetailsResponseV3.class);
            } catch (Fault_Exception | RuntimeException e) {
                throw new TFMicroServiceException(TFMicroServicesConstant.MS_001_ERROR_CODE,
                        TFMicroServicesConstant.MS_001_ERROR_MESSAGE, e.getMessage(), e);
            }
            if (subscriber == null) {
                tfOneCarrierSubscriber = BalanceInquiryHelper.populateTFOneCarrierSubscriber(response);
            } else {
                tfOneCarrierSubscriber = BalanceInquiryHelper.populateTFOneCarrierSubscriberWithBuckets(response, subscriber);
            }
        } else {
            tfOneCarrierSubscriber = subscriber;
        }
        log.info("TFOneCarrierSubscriber " + tfOneCarrierSubscriber);
        return tfOneCarrierSubscriber;
    }

    protected QuerySubscriberDetailsResponseV3 getResponse(QuerySubscriberDetailsRequestV3 request) throws Fault_Exception {
        TmobileMeshInquiry tmobileMeshInquiry = new TmobileMeshInquiry();
        if(PropertyHelper.isUseMesh()){
            return tmobileMeshInquiry.processQuerySubscriberDetails(request);
        }
        return WholesaleServicesV2StubSingleton.getInstance().getCXFService().querySubscriberDetailsV3(request);
    }

    public TFOneCarrierSubscriber validateSimByIccid(String iccid) {
        QueryInfoRequestV3 request = BalanceInquiryHelper
                .populateSimValidationRequestV3ForIccid(iccid);
        return validateSim(request);
    }

    @Override
    public TFOneCarrierSubscriber validateSim(QueryInfoRequestV3 request) {
        QueryInfoResponseV3 response = null;
        try {
            response = getSimValidateResponse(request);
            log.info(RESPONSE + response);
        } catch (Fault_Exception | RuntimeException e) {
            throw new TFMicroServiceException(TFMicroServicesConstant.MS_001_ERROR_CODE,
                    TFMicroServicesConstant.MS_001_ERROR_MESSAGE, e.getMessage(), e);
        }
        return BalanceInquiryHelper.populateQueryInfoResponseTypeV3(response);
    }

    protected QueryInfoResponseV3 getSimValidateResponse(QueryInfoRequestV3 request) throws Fault_Exception {
        TmobileMeshInquiry tmobileMeshInquiry = new TmobileMeshInquiry();
        if(PropertyHelper.isUseMesh()){
            return tmobileMeshInquiry.processQuerySim(request);
        }
        return WholesaleServicesV2StubSingleton.getInstance().getCXFService().queryInfoV3(request);
    }

    @Override
    public TFOneCarrierSubscriber inquireByAccountNum(String accountNum) {
        QueryAccountRequest request = BalanceInquiryHelper
                .populateQueryAccountRequest(accountNum);
        return inquireAccount(request);
    }

    @Override
    public TFOneCarrierSubscriber inquireAccount(QueryAccountRequest request) {
        QueryAccountResponse response = null;
        try {
            response = getAccountResponse(request);
            log.info(RESPONSE + response);
        } catch (Fault_Exception | RuntimeException e) {
            log.error(e);
            throw new TFMicroServiceException(TFMicroServicesConstant.MS_001_ERROR_CODE,
                    TFMicroServicesConstant.MS_001_ERROR_MESSAGE, e.getMessage(), e);
        }
        return BalanceInquiryHelper.populateQueryAccountResponse(response);
    }

    protected QueryAccountResponse getAccountResponse(QueryAccountRequest request) throws Fault_Exception {
        TmobileMeshInquiry tmobileMeshInquiry = new TmobileMeshInquiry();
        if(PropertyHelper.isUseMesh()){
            return tmobileMeshInquiry.processAccountNumber(request);
        }
        return WholesaleServicesV2StubSingleton.getInstance().getCXFService().queryAccount(request);
    }

    @Override
    public TFOneCarrierSubscriber validateSimByIccid2(String iccid) {
        QueryInfoRequestV3 request = BalanceInquiryHelper
                .populateQuerySubscriberDetailsRequestV3ForIccid2(iccid);
        return validateSim2(request);
    }

    @Override
    public TFOneCarrierSubscriber validateSim2(QueryInfoRequestV3 request) {
        String response = null;
        try {
            response = getSim2ValidateResponse(request);
            log.info(RESPONSE + response);
        } catch ( RuntimeException e) {
            throw new TFMicroServiceException(TFMicroServicesConstant.MS_001_ERROR_CODE,
                    TFMicroServicesConstant.MS_001_ERROR_MESSAGE, e.getMessage(), e);
        }
        return BalanceInquiryHelper.populateQueryInfoTmo(response);
    }

    protected String getSim2ValidateResponse(QueryInfoRequestV3 request) {
        TmobileMeshInquiry tmobileMeshInquiry = new TmobileMeshInquiry();
        return tmobileMeshInquiry.processValidateSim2(request);
    }

}
