package com.tracfone.inquiry.tmobile.service;

import com.tracfone.igate.cxf.clients.WholesaleServicesV2PortEndpoint;
import com.tracfone.igate.cxf.clients.WholesaleServicesV2Service;
import com.tracfone.inquiry.tmobile.helper.PropertyHelper;
import lombok.extern.log4j.Log4j2;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
public class WholesaleServicesV2StubSingleton {

    private static WholesaleServicesV2StubSingleton stub;
    static WholesaleServicesV2Service service = null;
    static WholesaleServicesV2PortEndpoint portEndPoint = null;

    private WholesaleServicesV2StubSingleton() {

        log.debug("WholesaleServicesV2StubSingleton constructor called ");

        service = new com.tracfone.igate.cxf.clients.WholesaleServicesV2Service();
        portEndPoint = service.getWholesaleServicesV2PortEndpoint();
        BindingProvider bindingProvider = (BindingProvider) portEndPoint;

        List<String> popList = new ArrayList<String>();
        Map<String, List<String>> headers = new HashMap<String, List<String>>();

        String nextGenServiceURL = PropertyHelper.getServiceURL();
        String nextGenKey = PropertyHelper.getKey();
        String nextGenSecret = PropertyHelper.getSecret();
        String nextGenPopToken = PropertyHelper.getPopToken();

        log.debug("NEXTGEN_SERVICE_URL: " + nextGenServiceURL + ", NEXTGEN_KEY: " + nextGenKey + ", NEXTGEN_SECRET: "
                + nextGenSecret + ", NEXTGEN_POP_TOKEN: " + nextGenPopToken);

        bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, nextGenServiceURL);
        bindingProvider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, nextGenKey);
        bindingProvider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, nextGenSecret);
        popList.add(nextGenPopToken);

        headers.put("popToken", popList);
        bindingProvider.getRequestContext().put(MessageContext.HTTP_REQUEST_HEADERS, headers);

    }
    public static synchronized WholesaleServicesV2StubSingleton getInstance() {
        log.debug("WholesaleServicesV2StubSingleton getInstance called");
        if (stub == null) {
            stub = new WholesaleServicesV2StubSingleton();
        }
        return stub;
    }

    public WholesaleServicesV2PortEndpoint getCXFService() {
        return portEndPoint;
    }

}