package com.tracfone.inquiry.tmobile.service;

import com.tracfone.igate.cxf.clients.QueryAccountRequest;
import com.tracfone.igate.cxf.clients.QueryInfoRequestV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsRequestV3;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;

public interface InquiryTmobileService {
    TFOneCarrierSubscriber balanceInquiryByMin(String min);

    TFOneCarrierSubscriber balanceInquiryByIccid(String iccid);

    TFOneCarrierSubscriber balanceInquiry(QuerySubscriberDetailsRequestV3 request, TFOneCarrierSubscriber subscriber);

    TFOneCarrierSubscriber validateSimByIccid(String iccid);

    TFOneCarrierSubscriber validateSim(QueryInfoRequestV3 request);

    TFOneCarrierSubscriber inquireByAccountNum(String accountNum);

    TFOneCarrierSubscriber inquireAccount(QueryAccountRequest request);

    TFOneCarrierSubscriber validateSimByIccid2(String iccid);

    TFOneCarrierSubscriber validateSim2(QueryInfoRequestV3 request);
}
