package com.tracfone.inquiry.tmobile.service;

import com.tracfone.igate.cxf.clients.QueryAccountRequest;
import com.tracfone.igate.cxf.clients.QueryAccountResponse;
import com.tracfone.igate.cxf.clients.QueryInfoRequestV3;
import com.tracfone.igate.cxf.clients.QueryInfoResponseV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsRequestV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsResponseV3;
import com.tracfone.inquiry.tmobile.filter.CorrelationIDFilter;
import com.tracfone.inquiry.tmobile.helper.PropertyHelper;
import com.tracfone.inquiry.tmobile.helper.XmlUtils;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;
import java.time.Duration;

import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.EXCEPTION_OCCURED;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.RESPONSE_RECEIVED;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.SENDING_REQUEST;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.SERVICE_URL;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.XML_REQUEST;

@Log4j2
@Component
public class TmobileMeshInquiry {

    @Autowired
    private WebClient webClient;

    public QuerySubscriberDetailsResponseV3 processQuerySubscriberDetails(QuerySubscriberDetailsRequestV3 request) {
        log.info("Populate the QuerySubscriberDetailsRequest");
        XmlUtils xmlUtils = new XmlUtils();

        QuerySubscriberDetailsResponseV3 response = null;
        String responseBody = "";
        String xmlStringRequest;
        String xmlString = xmlUtils.jaxbObjectToXMLStringNG(request);
        log.debug(SERVICE_URL, PropertyHelper.getMeshUrl());
        if (StringUtils.isNotBlank(xmlString)) {
            try {
                log.debug(SENDING_REQUEST);
                xmlStringRequest = PropertyHelper.getSoapElementFirst() + xmlString + PropertyHelper.getSoapElementLast();
                log.debug(XML_REQUEST, xmlStringRequest);
                responseBody = createWebClient().post()
                        .uri(PropertyHelper.getMeshUrl())
                        .contentType(MediaType.TEXT_XML)
                        .header(CorrelationIDFilter.CORRELATION_ID_KEY)
                        .bodyValue(xmlStringRequest)
                        .retrieve()
                        .onStatus(HttpStatus::isError, res -> res.bodyToMono(String.class) // error body as String or other class
                                .flatMap(error -> Mono.error(new Exception(error)))) // throw a functional exception
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(PropertyHelper.getTimeout()))
                        .block();

                if (StringUtils.isNotBlank(responseBody)) {
                    log.debug(RESPONSE_RECEIVED + responseBody);
                    response = xmlUtils.xMLStringTojaxbObjectNG(responseBody);
                }

            } catch (Exception e) {
                log.error(EXCEPTION_OCCURED, e);
            }
        }
        return response;
    }

    public String processValidateSim2(QueryInfoRequestV3 request) {
        log.info("Populate the QueryInfoRequestV3");
        XmlUtils xmlUtils = new XmlUtils();

        String responseBody = "";
        String xmlStringRequest;
        String xmlString = xmlUtils.jaxbObjectToXMLStringSim2(request);
        log.debug(SERVICE_URL, PropertyHelper.getMeshUrl());
        if (StringUtils.isNotBlank(xmlString)) {
            try {
                log.debug(SENDING_REQUEST);
                xmlStringRequest = PropertyHelper.getSoapElementFirst() + xmlString + PropertyHelper.getSoapElementLast();
                log.debug(XML_REQUEST, xmlStringRequest);
                responseBody = createWebClient().post()
                        .uri(PropertyHelper.getMeshUrl())
                        .contentType(MediaType.TEXT_XML)
                        .header(CorrelationIDFilter.CORRELATION_ID_KEY)
                        .bodyValue(xmlStringRequest)
                        .retrieve()
                        .onStatus(HttpStatus::isError, res -> res.bodyToMono(String.class) // error body as String or other class
                                .flatMap(error -> Mono.error(new Exception(error)))) // throw a functional exception
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(PropertyHelper.getTimeout()))
                        .block();

                if (StringUtils.isNotBlank(responseBody)) {
                    log.debug(RESPONSE_RECEIVED + responseBody);
                    log.info(RESPONSE_RECEIVED + responseBody);
                }

            } catch (Exception e) {
                log.error(EXCEPTION_OCCURED, e);
            }
        }
        return responseBody;
    }

    public QueryInfoResponseV3 processQuerySim(QueryInfoRequestV3 request) {
        log.info("Populate the QueryInfoRequestV3");
        XmlUtils xmlUtils = new XmlUtils();

        QueryInfoResponseV3 response = null;
        String responseBody = "";
        String xmlStringRequest;
        String xmlString = xmlUtils.jaxbObjectToXMLStringSim2(request);
        log.debug(SERVICE_URL, PropertyHelper.getMeshUrl());
        if (StringUtils.isNotBlank(xmlString)) {
            try {
                log.debug(SENDING_REQUEST);
                xmlStringRequest = PropertyHelper.getSoapElementFirst() + xmlString + PropertyHelper.getSoapElementLast();
                log.debug(XML_REQUEST, xmlStringRequest);
                responseBody = createWebClient().post()
                        .uri(PropertyHelper.getMeshUrl())
                        .contentType(MediaType.TEXT_XML)
                        .header(CorrelationIDFilter.CORRELATION_ID_KEY)
                        .bodyValue(xmlStringRequest)
                        .retrieve()
                        .onStatus(HttpStatus::isError, res -> res.bodyToMono(String.class) // error body as String or other class
                                .flatMap(error -> Mono.error(new Exception(error)))) // throw a functional exception
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(PropertyHelper.getTimeout()))
                        .block();

                if (StringUtils.isNotBlank(responseBody)) {
                    log.debug(RESPONSE_RECEIVED + responseBody);
                    response = xmlUtils.xMLStringTojaxbObjectSim(responseBody);
                }

            } catch (Exception e) {
                log.error(EXCEPTION_OCCURED, e);
            }
        }
        return response;
    }

    public QueryAccountResponse processAccountNumber(QueryAccountRequest request) {
        log.info("Populate the QueryAccountRequest");
        XmlUtils xmlUtils = new XmlUtils();

        QueryAccountResponse response = null;
        String responseBody = "";
        String xmlStringRequest;
        String xmlString = xmlUtils.jaxbObjectToXMLStringAccount(request);
        log.debug(SERVICE_URL, PropertyHelper.getMeshUrl());
        if (StringUtils.isNotBlank(xmlString)) {
            try {
                log.debug(SENDING_REQUEST);
                xmlStringRequest = PropertyHelper.getSoapElementFirst() + xmlString + PropertyHelper.getSoapElementLast();
                log.debug(XML_REQUEST, xmlStringRequest);
                responseBody = createWebClient().post()
                        .uri(PropertyHelper.getMeshUrl())
                        .contentType(MediaType.TEXT_XML)
                        .header(CorrelationIDFilter.CORRELATION_ID_KEY)
                        .bodyValue(xmlStringRequest)
                        .retrieve()
                        .onStatus(HttpStatus::isError, res -> res.bodyToMono(String.class) // error body as String or other class
                                .flatMap(error -> Mono.error(new Exception(error)))) // throw a functional exception
                        .bodyToMono(String.class)
                        .timeout(Duration.ofSeconds(PropertyHelper.getTimeout()))
                        .block();

                if (StringUtils.isNotBlank(responseBody)) {
                    log.debug(RESPONSE_RECEIVED + responseBody);
                    response = xmlUtils.XMLStringTojaxbObjectAccount(responseBody);
                }

            } catch (Exception e) {
                log.error(EXCEPTION_OCCURED, e);
            }
        }
        return response;
    }

    public WebClient createWebClient() throws SSLException {
        SslContext sslContext = SslContextBuilder
                .forClient()
                .trustManager(InsecureTrustManagerFactory.INSTANCE)
                .build();
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(sslContext));
        return WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClient)).build();
    }

}
