package com.tracfone.inquiry.tmobile.controller;

import com.tracfone.inquiry.common.exception.ExceptionHandlerUtil;
import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.tmobile.service.InquiryTmobileService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.REQUEST_RECEIVED;

@Log4j2
@RestController
@RequestMapping(path = "/api/tmobile/genesys")
public class InquiryTmobileController {

    @Autowired
    InquiryTmobileService tmobileBalanceInquiryService;

    /**
     * Balance inquiry Rest service.
     * <p>
     * http://localhost:8082/api/tmobile/genesys/inquiry/min/7862124910
     * http://localhost:8082/api/tmobile/genesys/inquiry/sim/8901260892131386845
     *
     * @param min
     * @return
     */
    @GetMapping(value = "/inquiry/carrier/{carrierId}/min/{minnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity balanceInquiryByMin(@PathVariable("minnumber") String min) {
        log.info("Request received = min:" + min);
        TFOneCarrierSubscriber response = null;
        try {
            response = tmobileBalanceInquiryService.balanceInquiryByMin(min);
            log.info("response received = response:" + response);
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @GetMapping(value = "/inquiry/carrier/{carrierId}/sim/{simnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity balanceInquiryBySim(@PathVariable("simnumber") String sim) {
        log.info(REQUEST_RECEIVED + sim);
        TFOneCarrierSubscriber response = null;
        try {
            response = tmobileBalanceInquiryService.balanceInquiryByIccid(sim);
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/validate/sim/{simnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity validateSim(@PathVariable("simnumber") String sim) {
        log.info("Validate SIM Service called");
        log.info(REQUEST_RECEIVED + sim);
        TFOneCarrierSubscriber response = null;
        try {
            response = tmobileBalanceInquiryService.validateSimByIccid(sim);
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/inquiry/accountNumber/{accountNumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity inquireByAccountNum(@PathVariable("accountNumber") String accountNumber) {
        log.info("Inquire by account number Service called");
        log.info("Request received = account number:" + accountNumber);
        TFOneCarrierSubscriber response = null;
        try {
            response = tmobileBalanceInquiryService.inquireByAccountNum(accountNumber);
        } catch (TFMicroServiceException ex) {
            log.error(ex);
            response = ExceptionHandlerUtil.handleExceptions(ex);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/validate/sim2/{simnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity validateSim2(@PathVariable("simnumber") String sim) {
        log.info("Validate SIM 2 Service called");
        log.info(REQUEST_RECEIVED + sim);
        TFOneCarrierSubscriber response = null;
        try {
            response = tmobileBalanceInquiryService.validateSimByIccid2(sim);
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
