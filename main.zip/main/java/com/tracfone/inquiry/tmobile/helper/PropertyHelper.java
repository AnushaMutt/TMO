package com.tracfone.inquiry.tmobile.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PropertyHelper {

    private static String serviceURL;
    private static String popToken;
    private static String key;
    private static String secret;
    private static String meshUrl;
    private static boolean useMesh;
    private static String soapElementFirst;
    private static String soapElementLast;
    private static Integer timeout;
    private static Integer partnerId;

    public static String getServiceURL() {
        return serviceURL;
    }

    @Value("${tmobile.nextgen.wholesale.service.url}")
    public void setServiceURL(String serviceURL) {
        PropertyHelper.serviceURL = serviceURL;
    }

    public static String getPopToken() {
        return popToken;
    }

    @Value("${tmobile.nextgen.wholesale.popToken}")
    public void setPopToken(String popToken) {
        PropertyHelper.popToken = popToken;
    }

    public static String getKey() {
        return key;
    }

    @Value("${tmobile.nextgen.wholesale.key}")
    public void setKey(String key) {
        PropertyHelper.key = key;
    }

    public static String getSecret() {
        return secret;
    }

    @Value("${tmobile.nextgen.wholesale.secret}")
    public void setSecret(String secret) {
        PropertyHelper.secret = secret;
    }

    public static String getMeshUrl() {
        return meshUrl;
    }

    @Value("${tmobile.nextgen.wholesale.service.meshUrl}")
    public void setMeshUrl(String meshUrl) {
        PropertyHelper.meshUrl = meshUrl;
    }

    public static boolean isUseMesh() {
        return useMesh;
    }

    @Value("${tmobile.nextgen.wholesale.service.useMesh}")
    public void setUseMesh(boolean useMesh) {
        PropertyHelper.useMesh = useMesh;
    }

    public static String getSoapElementFirst() {
        return soapElementFirst;
    }
    @Value("${SOAP_ELEMENT_FIRST}")
    public void setSoapElementFirst(String soapElementFirst) {
        PropertyHelper.soapElementFirst = soapElementFirst;
    }

    public static String getSoapElementLast() {
        return soapElementLast;
    }
    @Value("${SOAP_ELEMENT_LAST}")
    public void setSoapElementLast(String soapElementLast) {
        PropertyHelper.soapElementLast = soapElementLast;
    }

    public static Integer getTimeout() {
        return timeout;
    }
    @Value("${TIMEOUT_DURATION}")
    public void setTimeout(Integer timeout) {
        PropertyHelper.timeout = timeout;
    }

    public static Integer getPartnerId() {
        return partnerId;
    }
    @Value("${PARTNER_ID}")
    public void setPartnerId(Integer partnerId) {
        PropertyHelper.partnerId = partnerId;
    }
}
