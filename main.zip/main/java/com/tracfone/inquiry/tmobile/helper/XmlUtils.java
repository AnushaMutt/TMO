package com.tracfone.inquiry.tmobile.helper;

import com.tracfone.igate.cxf.clients.QueryAccountRequest;
import com.tracfone.igate.cxf.clients.QueryAccountResponse;
import com.tracfone.igate.cxf.clients.QueryInfoRequestV3;
import com.tracfone.igate.cxf.clients.QueryInfoResponseV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsRequestV3;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsResponseV3;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPMessage;
import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.util.Objects;

/**
 * @author gaurav.sharma
 */

@Log4j2
@Component
public class XmlUtils {

    public String jaxbObjectToXMLStringNG(QuerySubscriberDetailsRequestV3 querySubscriberDetailsRequestV3) {
        String xmlString = "";
        try {

            if(Objects.nonNull(querySubscriberDetailsRequestV3)) {
                StringWriter sw = new StringWriter();

                Marshaller jaxbMarshaller = JAXBContext.newInstance(QuerySubscriberDetailsRequestV3.class).createMarshaller();
                jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
                jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);// To remove xml header
                jaxbMarshaller.marshal(querySubscriberDetailsRequestV3, sw);
                xmlString = sw.toString();

                log.debug("jaxbObjectToXMLStringNG conversion completed ");
            }
        } catch (NullPointerException e) {
            log.error("NullPointerException occurred while converting jaxbObjectToXMLStringNG");
        } catch (Exception e) {
            log.error("Exception occurred while converting jaxbObjectToXMLStringNG");
            log.error(e);
        }

        return xmlString;
    }


    public QuerySubscriberDetailsResponseV3 xMLStringTojaxbObjectNG(String result) {
        QuerySubscriberDetailsResponseV3 querySubscriberDetailsResponseV3 = null;

        try {
            if(StringUtils.isNotBlank(result)) {
                SOAPMessage message = MessageFactory.newInstance().createMessage(null,
                        new ByteArrayInputStream(result.getBytes()));

                Unmarshaller jaxbUnmarshaller = JAXBContext.newInstance(QuerySubscriberDetailsResponseV3.class).createUnmarshaller();

                querySubscriberDetailsResponseV3 = (QuerySubscriberDetailsResponseV3) jaxbUnmarshaller.unmarshal(message.getSOAPBody().extractContentAsDocument());

                log.debug("XMLStringTojaxbObjectNG: conversion completed");
            }
        } catch (NullPointerException e) {
            log.error("NullPointerException occurred while converting XMLStringTojaxbObjectNG");
        } catch (Exception e) {
            log.error("Exception occurred while converting XMLStringTojaxbObjectNG");
            log.error(e);
        }
        return querySubscriberDetailsResponseV3;
    }

    public String jaxbObjectToXMLStringSim2(QueryInfoRequestV3 queryInfoRequestV3) {
        String xmlString = "";
        try {

            if(Objects.nonNull(queryInfoRequestV3)) {
                StringWriter sw = new StringWriter();

                Marshaller jaxbMarshaller = JAXBContext.newInstance(QueryInfoRequestV3.class).createMarshaller();
                jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
                jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);// To remove xml header
                jaxbMarshaller.marshal(queryInfoRequestV3, sw);
                xmlString = sw.toString();

                log.debug("jaxbObjectToXMLStringSim2 conversion completed ");
            }
        } catch (NullPointerException e) {
            log.error("NullPointerException occurred while converting jaxbObjectToXMLStringSim2");
        } catch (Exception e) {
            log.error("Exception occurred while converting jaxbObjectToXMLStringSim2");
            log.error(e);
        }
        return xmlString;
    }


    public QueryInfoResponseV3 xMLStringTojaxbObjectSim(String result) {
        QueryInfoResponseV3 queryInfoResponseV3 = null;

        try {
            if(StringUtils.isNotBlank(result)) {
                SOAPMessage message = MessageFactory.newInstance().createMessage(null,
                        new ByteArrayInputStream(result.getBytes()));

                Unmarshaller jaxbUnmarshaller = JAXBContext.newInstance(QueryInfoResponseV3.class).createUnmarshaller();

                queryInfoResponseV3 = (QueryInfoResponseV3) jaxbUnmarshaller.unmarshal(message.getSOAPBody().extractContentAsDocument());

                log.debug("XMLStringTojaxbObjectSim: conversion completed");
            }
        } catch (NullPointerException e) {
            log.error("NullPointerException occurred while converting XMLStringTojaxbObjectSim");
        } catch (Exception e) {
            log.error("Exception occurred while converting XMLStringTojaxbObjectSim");
            log.error(e);
        }
        return queryInfoResponseV3;
    }

    public String jaxbObjectToXMLStringAccount(QueryAccountRequest queryAccountRequest) {
        String xmlString = "";
        try {

            if(Objects.nonNull(queryAccountRequest)) {
                StringWriter sw = new StringWriter();
                Marshaller jaxbMarshaller = JAXBContext.newInstance(QueryAccountRequest.class).createMarshaller();
                jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
                jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);// To remove xml header
                jaxbMarshaller.marshal(queryAccountRequest, sw);
                xmlString = sw.toString();

                log.debug("jaxbObjectToXMLStringAccount conversion completed ");
            }
        } catch (NullPointerException e) {
            log.error("NullPointerException occurred while converting jaxbObjectToXMLStringAccount");
        } catch (Exception e) {
            log.error("Exception occurred while converting jaxbObjectToXMLStringAccount");
            log.error(e);
        }
        return xmlString;
    }

    public QueryAccountResponse XMLStringTojaxbObjectAccount(String result) {
        QueryAccountResponse queryAccountResponse = null;

        try {
            if(StringUtils.isNotBlank(result)) {
                SOAPMessage message = MessageFactory.newInstance().createMessage(null,
                        new ByteArrayInputStream(result.getBytes()));

                Unmarshaller jaxbUnmarshaller = JAXBContext.newInstance(QueryAccountResponse.class).createUnmarshaller();

                queryAccountResponse = (QueryAccountResponse) jaxbUnmarshaller.unmarshal(message.getSOAPBody().extractContentAsDocument());

                log.debug("XMLStringTojaxbObjectAccount: conversion completed");
            }
        } catch (NullPointerException e) {
            log.error("NullPointerException occurred while converting XMLStringTojaxbObjectAccount");
        } catch (Exception e) {
            log.error("Exception occurred while converting XMLStringTojaxbObjectAccount");
            log.error(e);
        }
        return queryAccountResponse;
    }


}
