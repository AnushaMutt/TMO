package com.tracfone.inquiry.tmobile.helper;

import com.tracfone.igate.cxf.clients.*;
import com.tracfone.igate.cxf.clients.QuerySubscriberDetailsResponseV3.Body.Response;
import com.tracfone.inquiry.common.constant.TFMicroServicesConstant;
import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneActionItemBucket;
import com.tracfone.inquiry.common.model.response.TFOneActionItemBucketTier;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.common.model.response.TFOneFeatures;
import com.tracfone.inquiry.common.model.response.TFOneRatePlan;
import com.tracfone.inquiry.common.model.response.TFOneRatePlanProfile;
import com.tracfone.inquiry.common.util.DateUtil;
import com.tracfone.inquiry.common.util.JAXBUtil;
import com.tracfone.inquiry.tmobile.constant.TmobileConstant;
import lombok.extern.log4j.Log4j2;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.tracfone.inquiry.common.constant.TFMicroServicesConstant.MS_002_ERROR_CODE;
import static com.tracfone.inquiry.common.constant.TFMicroServicesConstant.MS_002_ERROR_MESSAGE;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.CONVERTED_TO;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.FORMAT_DATE;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.QUERY_SIM;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.QUERY_SIM2;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.RESPONSE_ERROR;
import static com.tracfone.inquiry.tmobile.constant.TmobileConstant.UNITS;

/**
 * Balance Inquiry Helper class
 *
 * @author
 */
@Log4j2
public class BalanceInquiryHelper {

    public static QuerySubscriberDetailsRequestV3 populateQuerySubscriberDetailsRequestV3ForMin(String min, String action) {
        return populateQuerySubscriberDetailsRequestV3(min, null, action);
    }

    public static QuerySubscriberDetailsRequestV3 populateQuerySubscriberDetailsRequestV3ForIccid(String iccid, String action) {
        return populateQuerySubscriberDetailsRequestV3(null, iccid, action);
    }

    public static QueryInfoRequestV3 populateSimValidationRequestV3ForIccid(String iccid) {
        return prepareQueryInfoRequest(iccid);
    }

    public static QueryAccountRequest populateQueryAccountRequest(String accountNum) {
        return prepareQueryAccountRequest(accountNum);
    }

    public static QueryInfoRequestV3 populateQuerySubscriberDetailsRequestV3ForIccid2(String iccid) {
        return sim2PopulateQuerySubscriberDetailsRequestV3( iccid);
    }

    public static QuerySubscriberDetailsRequestV3 populateQuerySubscriberDetailsRequestV3(String min, String iccid, String action) {
        QuerySubscriberDetailsTypeV3 querySubscriberDetailsTypeV3 = new QuerySubscriberDetailsTypeV3();
        querySubscriberDetailsTypeV3.setAction(action);
        if (min != null) {
            querySubscriberDetailsTypeV3.setMSISDN(min);
        }
        if (iccid != null) {
            querySubscriberDetailsTypeV3.setICCID(iccid);
        }

        QuerySubscriberDetailsRequestV3.Body.Request req = new QuerySubscriberDetailsRequestV3.Body.Request();
        req.setPartnerID(PropertyHelper.getPartnerId());
        req.setPartnerTransactionID(TmobileConstant.BI + DateUtil.getNewXMLGregorianCalendar());
        req.setQuerySubscriberDetails(querySubscriberDetailsTypeV3);

        QuerySubscriberDetailsRequestV3.Body body = new QuerySubscriberDetailsRequestV3.Body();
        body.getRequest().add(req);
        body.setRequestCount(body.getRequest().size());

        QuerySubscriberDetailsRequestV3 querySubscriberDetailsRequestV3 = new QuerySubscriberDetailsRequestV3();
        querySubscriberDetailsRequestV3.setHeader(populateHeaderTypeV3());
        querySubscriberDetailsRequestV3.setBody(body);

        JAXBUtil.marshalObject(querySubscriberDetailsRequestV3, QuerySubscriberDetailsRequestV3.class);

        return querySubscriberDetailsRequestV3;
    }

    public static QueryInfoRequestV3 prepareQueryInfoRequest(String iccid) {
        log.debug(" Request:  prepareQueryInfoRequest....");
        QueryInfoRequestV3 queryInfoReq = new QueryInfoRequestV3();
        QueryInfoRequestV3.Body body = new QueryInfoRequestV3.Body();
        QueryInfoRequestV3.Body.Request request = new QueryInfoRequestV3.Body.Request();
        request.setPartnerID(PropertyHelper.getPartnerId());
        request.setPartnerTransactionID(TmobileConstant.QS + DateUtil.getNewXMLGregorianCalendar());
        QueryInfoTypeV3 queryInfoTypeV3 = new QueryInfoTypeV3();
        queryInfoTypeV3.setAction(QUERY_SIM);
        queryInfoTypeV3.setICCID(iccid);
        request.setQueryInfo(queryInfoTypeV3);
        body.getRequest().add(request);
        body.setRequestCount(body.getRequest().size());
        queryInfoReq.setHeader(populateHeaderTypeV3());
        queryInfoReq.setBody(body);
        return queryInfoReq;
    }

    public static QueryAccountRequest prepareQueryAccountRequest(String accountNum) {
        log.debug(" Request:  prepareQueryAccountRequest....");
        QueryAccountRequest queryAccReq = new QueryAccountRequest();
        QueryAccountRequest.Body body = new QueryAccountRequest.Body();
        QueryAccountRequest.Body.Request request = new QueryAccountRequest.Body.Request();
        request.setPartnerID(PropertyHelper.getPartnerId());
        request.setPartnerTransactionID(TmobileConstant.QAR + DateUtil.getNewXMLGregorianCalendar());
        QueryAccountRequest.Body.Request.QueryAccount queryAccount = new QueryAccountRequest.Body.Request.QueryAccount();
        AccountIDTypeV3 accountID = new AccountIDTypeV3();
        accountID.setValue(accountNum);
        accountID.setIsMultiline(true);
        queryAccount.setAccountID(accountID);
        request.getQueryAccount().add(queryAccount);
        queryAccReq.setHeader(populateHeaderTypeV3());
        body.setRequest(request);
        queryAccReq.setBody(body);
        try {
            JAXBContext context = JAXBContext.newInstance(QueryAccountRequest.class);
            Marshaller m = context.createMarshaller();
            StringWriter writer = new StringWriter();
            m.marshal(queryAccReq, writer);
            String xmlRequest = writer.toString();
            log.info("xmlRequest " + xmlRequest);
        } catch (Exception e) {
            log.error("Error when retrieving data from request", e);
        }
        return queryAccReq;
    }

    public static QueryInfoRequestV3 sim2PopulateQuerySubscriberDetailsRequestV3(String iccid) {
        log.debug(" Request:  prepareQueryInfoRequest....");
        QueryInfoRequestV3 queryInfoReq = new QueryInfoRequestV3();
        QueryInfoRequestV3.Body body = new QueryInfoRequestV3.Body();
        QueryInfoRequestV3.Body.Request request = new QueryInfoRequestV3.Body.Request();
        request.setPartnerID(PropertyHelper.getPartnerId());
        request.setPartnerTransactionID(TmobileConstant.QS + DateUtil.getNewXMLGregorianCalendar());
        QueryInfoTypeV3 queryInfoTypeV3 = new QueryInfoTypeV3();
        queryInfoTypeV3.setAction(QUERY_SIM2);
        queryInfoTypeV3.setICCID(iccid);
        request.setQueryInfo(queryInfoTypeV3);
        body.getRequest().add(request);
        body.setRequestCount(body.getRequest().size());
        queryInfoReq.setHeader(populateHeaderTypeV3());
        queryInfoReq.setBody(body);
        return queryInfoReq;
    }


    public static HeaderTypeV3 populateHeaderTypeV3() {
        HeaderTypeV3 headerTypeV3 = new HeaderTypeV3();
        headerTypeV3.setSenderID(PropertyHelper.getPartnerId());
        headerTypeV3.setTranDateTime(DateUtil.getNewXMLGregorianCalendar());
        headerTypeV3.setCallBackLocation(TmobileConstant.CALLBACK_URL);
        return headerTypeV3;
    }

    public static TFOneCarrierSubscriber populateQueryInfoResponseTypeV3(QueryInfoResponseV3 response) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        Map<String, String> validateSimMap = new HashMap<>();

        QueryInfoResponseV3.Body body = response.getBody();
        List<QueryInfoResponseV3.Body.Response> responses = body.getResponse();
        List<QueryInfoResponseTypeV3> queryInfoList = responses.get(0).getQueryInfo();
        QueryInfoResponseTypeV3 carrierResponse = null;
        if (!queryInfoList.isEmpty()) {
            carrierResponse = queryInfoList.get(0);
        }

        if (carrierResponse == null) {
            log.error("QuerySIM Service Failed");
            return subscriber;
        }
        subscriber.setEsn(carrierResponse.getIMEI());
        subscriber.setSim(carrierResponse.getICCID());
        subscriber.setMin(carrierResponse.getMSISDN());
        subscriber.setStatus(carrierResponse.getStatus());
        log.info("imei " + carrierResponse.getIMEI());
        log.info("iccid" + carrierResponse.getICCID());
        log.info("min" + carrierResponse.getMSISDN());

        try {
            JAXBContext context = JAXBContext.newInstance(QueryInfoResponseV3.class);
            Marshaller m = context.createMarshaller();
            StringWriter writer = new StringWriter();
            m.marshal(response, writer);
            String xmlResponse = writer.toString();
            log.info("xmlResponse " + xmlResponse);

            String xPathSimResponse = "//ICCIDInfo";
            NodeList responseNodes = getValueFromXPath(xmlResponse, xPathSimResponse);
            // Iterate all nodes under ICCIDInfo.
            for (int x = 0; x < responseNodes.getLength(); x++) {
                Node node = responseNodes.item(x);
                NodeList responseChildNodes = node.getChildNodes();

                // Iterate each field of the ICCIDInfo.
                for (int i = 0; i < responseChildNodes.getLength(); i++) {
                    String nodeName = responseChildNodes.item(i).getNodeName();
                    log.info("node name for validate sim is " + nodeName);
                    String value = responseChildNodes.item(i).getTextContent();
                    log.info("node value for validate sim is " + value);
                    if (value != null && !StringUtils.isEmpty(value)) {
                        if (nodeName.contains("Date")) {
                            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            Date date = formatter.parse(value);
                            formatter = new SimpleDateFormat(FORMAT_DATE);
                            value = formatter.format(date);
                        }
                        validateSimMap.put(nodeName, value);
                    }
                }
            }
        } catch (Exception e) {
            log.error(RESPONSE_ERROR, e);
            throw new TFMicroServiceException(MS_002_ERROR_CODE, MS_002_ERROR_MESSAGE);
        }

        List<ResultTypeV3> results = carrierResponse.getResult();
        if (results != null) {
            for (ResultTypeV3 result : results) {
                validateSimMap.put("result", result.getResult());
                validateSimMap.put("resultMsg", result.getResultMsg());
                validateSimMap.put("resultStatus", result.getStatus());
            }
        }

        log.info("Validate SIM Map " + validateSimMap);
        List<Map<String, String>> additionalFields = new ArrayList<>();
        additionalFields.add(validateSimMap);
        subscriber.setAdditionalFields(additionalFields);
        return subscriber;
    }

    public static TFOneCarrierSubscriber populateQueryAccountResponse(QueryAccountResponse response) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        List<Map<String, String>> additionalFields = new ArrayList<>();
        Map<String, String> inquireAccount = null;
        QueryAccountResponse.Body body = response.getBody();
        QueryAccountResponse.Body.Response responses = body.getResponse();
        List<QueryAccountResponse.Body.Response.QueryAccount> queryAccountList = responses.getQueryAccount();
        QueryAccountResponse.Body.Response.QueryAccount carrierResponse = null;
        if (!queryAccountList.isEmpty()) {
            carrierResponse = queryAccountList.get(0);
        }
        if (carrierResponse == null) {
            log.error("Inquire By Account Number Service Failed");
            return subscriber;
        }
        List<ResultTypeV3> results = carrierResponse.getResult();
        if (results != null) {
            for (ResultTypeV3 result : results) {
                subscriber.setStatus(result.getResult() + " - " + result.getStatus());
                if (!StringUtils.isEmpty(result.getResultMsg())) {
                    subscriber.setCarrierErrorMessage(result.getResult() + " - " + result.getStatus() + " - " + result.getResultMsg());
                }
            }
        }

        try {
            JAXBContext context = JAXBContext.newInstance(QueryAccountResponse.class);
            Marshaller m = context.createMarshaller();
            StringWriter writer = new StringWriter();
            m.marshal(response, writer);
            String xmlResponse = writer.toString();
            log.info("xmlResponse " + xmlResponse);

            String xPathSimResponse = "//subscriberInfo";
            NodeList responseNodes = getValueFromXPath(xmlResponse, xPathSimResponse);
            // Iterate all nodes under subscriberInfo.
            for (int x = 0; x < responseNodes.getLength(); x++) {
                Node node = responseNodes.item(x);
                NodeList responseChildNodes = node.getChildNodes();
                inquireAccount = new HashMap<>();
                inquireAccount.put("isMultiline", String.valueOf(carrierResponse.getAccountInfo().getAccountID().isIsMultiline()));
                // Iterate each field of the subscriberInfo.
                for (int i = 0; i < responseChildNodes.getLength(); i++) {
                    String nodeName = responseChildNodes.item(i).getNodeName();
                    log.info("node name for account number inquire is " + nodeName);
                    String value = responseChildNodes.item(i).getTextContent();
                    log.info("node value for account number inquire is " + value);
                    if (value != null && !StringUtils.isEmpty(value)) {
                        if (nodeName.contains("Date")) {
                            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
                            Date date = formatter.parse(value);
                            formatter = new SimpleDateFormat(FORMAT_DATE);
                            value = formatter.format(date);
                        }
                        inquireAccount.put(nodeName, value);
                    }
                }
                additionalFields.add(inquireAccount);
            }
        } catch (Exception e) {
            log.error(RESPONSE_ERROR, e);
            throw new TFMicroServiceException(MS_002_ERROR_CODE, MS_002_ERROR_MESSAGE);
        }
        subscriber.setAdditionalFields(additionalFields);
        log.info("subscriber for account inquiry = " + subscriber);
        return subscriber;
    }

    public static TFOneCarrierSubscriber populateQueryInfoTmo(String response) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        Map<String, String> validateSimMap = new HashMap<>();
        QueryInfoResponseV3 querySubscriberDetailsResponseV3 = null;

        log.info("response from sim inquiry is "+ response);

        if (org.apache.commons.lang.StringUtils.isBlank(response)) {
            log.error(RESPONSE_ERROR, response);
            throw new TFMicroServiceException(MS_002_ERROR_CODE, MS_002_ERROR_MESSAGE);
        }
        try {
            if(org.apache.commons.lang.StringUtils.isNotBlank(response)) {
                SOAPMessage message = MessageFactory.newInstance().createMessage(null,
                        new ByteArrayInputStream(response.getBytes()));
                Unmarshaller jaxbUnmarshaller = JAXBContext.newInstance(QueryInfoResponseV3.class).createUnmarshaller();
                querySubscriberDetailsResponseV3 = (QueryInfoResponseV3) jaxbUnmarshaller.unmarshal(message.getSOAPBody().extractContentAsDocument());
            }
        } catch (NullPointerException e) {
            log.error("NullPointerException occurred while converting XMLStringToQuerySubscriberDetailsRequestjaxbObjectNG");
        } catch (Exception e) {
            log.error("Exception occurred while converting XMLStringTojaxbObjectNG");
            log.error(e);
        }

        List<QueryInfoResponseV3.Body.Response> responses = null;
        if(querySubscriberDetailsResponseV3 != null){
            responses = querySubscriberDetailsResponseV3.getBody().getResponse();
        }
        List<QueryInfoResponseTypeV3> queryInfoList = null;
        if(responses != null){
            queryInfoList = responses.get(0).getQueryInfo();
        }
        QueryInfoResponseTypeV3 carrierResponse = null;
        if (queryInfoList != null && queryInfoList.isEmpty()) {
            carrierResponse = queryInfoList.get(0);
            if (carrierResponse == null) {
                log.error("QuerySIM Service Failed");
                return subscriber;
            }
        }

        if(carrierResponse != null) {
            subscriber.setEsn(carrierResponse.getIMEI());
            subscriber.setSim(carrierResponse.getICCID());
            subscriber.setMin(carrierResponse.getMSISDN());
            subscriber.setStatus(carrierResponse.getStatus());
            log.info("imei " + carrierResponse.getIMEI());
            log.info("iccid" + carrierResponse.getICCID());
            log.info("min" + carrierResponse.getMSISDN());
        }

        try {
            String xPathSimResponse = "//*[local-name()='ICCIDInfo']";
            log.info("xPathSimResponse "+xPathSimResponse );
            NodeList responseNodes = getValueFromXPath(response, xPathSimResponse);

            log.info("responseNodes "+responseNodes.getLength());
            // Iterate all nodes under ICCIDInfo.
            for (int x = 0; x < responseNodes.getLength(); x++) {
                Node node = responseNodes.item(x);
                NodeList responseChildNodes = node.getChildNodes();

                // Iterate each field of the ICCIDInfo.
                for (int i = 0; i < responseChildNodes.getLength(); i++) {
                    String nodeName = responseChildNodes.item(i).getNodeName();
                    nodeName = nodeName.substring(nodeName.indexOf(":")+1);
                    log.info("node name for validate sim is " + nodeName);
                    String value = responseChildNodes.item(i).getTextContent();
                    log.info("node value for validate sim is " + value);
                    if (value != null && !StringUtils.isEmpty(value)) {
                        if (nodeName.contains("Date")) {
                            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            Date date = formatter.parse(value);
                            formatter = new SimpleDateFormat(FORMAT_DATE);
                            value = formatter.format(date);
                        }
                        validateSimMap.put(nodeName, value);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(RESPONSE_ERROR, e);
            throw new TFMicroServiceException(MS_002_ERROR_CODE, MS_002_ERROR_MESSAGE);
        }

        List<ResultTypeV3> results = null;
        if(carrierResponse != null){
            results = carrierResponse.getResult();
        }

        if (results != null) {
            for (ResultTypeV3 result1 : results) {
                validateSimMap.put("result", result1.getResult());
                validateSimMap.put("resultMsg", result1.getResultMsg());
                validateSimMap.put("resultStatus", result1.getStatus());
            }
        }

        log.info("Validate SIM Map " + validateSimMap);
        List<Map<String, String>> additionalFields = new ArrayList<>();
        additionalFields.add(validateSimMap);
        subscriber.setAdditionalFields(additionalFields);
        log.info(" subscriber" + subscriber );
        return subscriber;

    }

    /**
     * Populates the TFOneCarrierSubscriber from the TMobile
     * QuerySubscriberDeails service response
     *
     * @param response
     * @return
     */
    public static TFOneCarrierSubscriber populateTFOneCarrierSubscriber(QuerySubscriberDetailsResponseV3 response) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        List<Response> responses = response.getBody().getResponse();
        if (!responses.isEmpty()) {
            ResultTypeV3 result = responses.get(0).getQuerySubscriberDetails().getResult().get(0);

            if (result.getResult().equals("100")) {
                QuerySubscriberDetailsResponseTypeV3 querySubscriberDetails = responses.get(0)
                        .getQuerySubscriberDetails();
                BaseProductTypeV4 baseProductTypeV4 = querySubscriberDetails.getBaseProduct();

                subscriber.setEsn(querySubscriberDetails.getIMEI());
                subscriber.setSim(querySubscriberDetails.getICCID());
                subscriber.setLineStatus(querySubscriberDetails.getSubscriberStatus());
                subscriber.setMin(querySubscriberDetails.getMSISDN());

                subscriber.setRateplanProfile(buildRatePlanProfile(baseProductTypeV4));
                if(!StringUtils.isEmpty(baseProductTypeV4.getBaseProductID())) {
                    setRatePlanName(subscriber, baseProductTypeV4);
                }
            } else {
                subscriber.setStatus(result.getStatus());
                subscriber.setErrorCode(MS_002_ERROR_CODE);
                subscriber.setErrorMessage(TFMicroServicesConstant.MS_002_ERROR_MESSAGE);
                subscriber.setCarrierErrorMessage(result.getResult() + ":" + result.getResultMsg());
            }

        }
        return subscriber;
    }

    /**
     * @return built object with rate plan and features.
     */
    private static TFOneRatePlan buildRatePlanProfile(BaseProductTypeV4 baseProductTypeV4) {
        TFOneRatePlan tfRatePlan = new TFOneRatePlan();
        if(!StringUtils.isEmpty(baseProductTypeV4.getBaseProductID())) {
            tfRatePlan.setRatePlanName(baseProductTypeV4.getBaseProductID());
        }
        List<TFOneFeatures> tfFeatures = new ArrayList<>();
        List<ProductTypeV3> products = baseProductTypeV4.getProduct();
        for (ProductTypeV3 product : products) {
            TFOneFeatures tfFeat = new TFOneFeatures();
            tfFeat.setFeatureValue(product.getProductID().getValue());
            tfFeatures.add(tfFeat);
        }
        TFOneRatePlanProfile tfRateplanProfile = new TFOneRatePlanProfile();
        tfRateplanProfile.setFeatures(tfFeatures);
        List<TFOneRatePlanProfile> ratePlanProfile = new ArrayList<>();
        ratePlanProfile.add(tfRateplanProfile);

        tfRatePlan.setRatePlanProfile(ratePlanProfile);
        return tfRatePlan;
    }

    /**
     * This method is used to build the bucket and tier information
     *
     * @param baseProductTypeV4
     * @return
     */
    private static List<TFOneActionItemBucket> buildBucketsAndTiers(BaseProductTypeV4 baseProductTypeV4) {
        List<TFOneActionItemBucket> buckets = new ArrayList<>();

        if (baseProductTypeV4 != null) {
            List<ProductTypeV3> productList = baseProductTypeV4.getProduct();
            log.info("productList is " + productList);
            if (productList != null && !productList.isEmpty()) {
                log.info("productList size is " + productList.size());
                for (ProductTypeV3 product : productList) {
                    List<UsageTypeV3> usageList = product.getUsage();
                    ProductRenewalInfoTypeV3 renewalInfoTypeV3 = product.getRenewalInfo();
                    Boolean isAutoRenew = renewalInfoTypeV3.isAutoRenew();
                    log.info("isAutoRenew is " + isAutoRenew);
                    String periodType = renewalInfoTypeV3.getPeriodType();
                    log.info("periodType is " + periodType);
                    String renewalDay = renewalInfoTypeV3.getRenewalDay();
                    log.info("renewalDay is " + renewalDay);
                    Integer periodValue = renewalInfoTypeV3.getPeriodValue();
                    log.info("periodValue is " + periodValue);
                    log.info("usageList is " + usageList);
                    TFOneActionItemBucket bucket;
                    for (UsageTypeV3 usage : usageList) {
                        log.info("usage is " + usage);
                        bucket = new TFOneActionItemBucket();
                        bucket.setBucketId(product.getProductID().getValue());

                        if (usage.getLimit() != null) {
                            bucket.setBucketCategory(usage.getLimit().getCategory());
                            bucket.setBucketType(usage.getLimit().getType());

                            if (usage.getLimit().getBucketValue() != null) {
                                bucket.setBucketValue(fetchUnits(usage.getLimit().getBucketValue().getUnit(), usage.getLimit().getBucketValue().getValue()));
                                bucket.setUnitOfMeasurement(usage.getLimit().getBucketValue().getUnit());
                            }

                            if (TmobileConstant.TETHER.equalsIgnoreCase(usage.getLimit().getType())) {
                                bucket.setBucketId(bucket.getBucketId() + "_" + usage.getLimit().getType());
                            }

                            buildBucketTiers(bucket, usage);
                        }

                        if (usage.getUsed() != null) {
                            bucket.setBucketUsage(fetchUnits(usage.getUsed().getUnit(), usage.getUsed().getValue()));
                        }

                        if (usage.getRemaining() != null) {
                            bucket.setBucketBalance(fetchUnits(usage.getRemaining().getUnit(), usage.getRemaining().getValue()));
                        }

                        bucket.setStatus(usage.getStatus());
                        bucket.setExpirationDate(product.getExpiryDateTime() == null ?
                                null : DateUtil.convertXMLGregorianCalendarToString(product.getExpiryDateTime(), DateUtil.FORMAT7));
                        if (isAutoRenew != null) {
                            bucket.setAutoRenewFlag(isAutoRenew.toString());
                        }
                        bucket.setAutoRenewDay(renewalDay);
                        bucket.setAutoRenewFrequency(periodType);
                        if (periodValue != null) {
                            bucket.setAutoRenewValue(periodValue.toString());
                        }
                        log.info("bucket is " + bucket);
                        buckets.add(bucket);
                    }
                    // Need to handle special buckets?
                }
            }
        }

        return buckets;
    }

    private static void buildBucketTiers(TFOneActionItemBucket bucket, UsageTypeV3 usage) {
        List<ThresholdsTypeV3> tiers = usage.getLimit().getThresholds();
        List<TFOneActionItemBucketTier> bucketTiers = new ArrayList<>();
        TFOneActionItemBucketTier bucketTier = null;
        for (ThresholdsTypeV3 tier : tiers) {
            bucketTier = new TFOneActionItemBucketTier();
            bucketTier.setTierBehavior(tier.getBehavior());
            bucketTier.setTierValue(tier.getThresholdValue().getValue());
            bucketTier.setUsageTierId(tier.getThresholdType());
            bucketTiers.add(bucketTier);
        }
        bucket.setBucketTiers(bucketTiers);
    }

    private static String fetchUnits(String units, String bucketValue) {
        String outputValue = "0";
        try {
            if (!StringUtils.isEmpty(units)) {
                if (units.equalsIgnoreCase("GB")) {
                    String gbValue = bucketValue;
                    double mbValue = 0;
                    if (!gbValue.equals("")) {
                        mbValue = new Double(gbValue) * 1024;
                        log.debug(UNITS + gbValue + ": " + units + CONVERTED_TO + mbValue + " MBs");
                    }
                    outputValue = mbValue + "";
                } else if (units.equalsIgnoreCase("MB")) {
                    String mbValue = bucketValue;
                    if (!StringUtils.isEmpty(mbValue)) {
                        outputValue = mbValue;
                        log.debug(UNITS + mbValue + ": " + units + " not required to convert");
                    }
                } else if (units.equalsIgnoreCase("KB")) {
                    String kbValue = bucketValue;
                    double mbValue = 0;
                    if (!kbValue.equals("")) {
                        mbValue = new Double(kbValue) / 1024;
                        log.debug(UNITS + kbValue + ": " + units + CONVERTED_TO + mbValue + " MBs");
                    }
                    outputValue = mbValue + "";
                } else if (units.equalsIgnoreCase("B")) {
                    String bValue = bucketValue;
                    double mbValue = 0;
                    if (!bValue.equals("")) {
                        mbValue = (new Double(bValue) / 1024) / 1024;
                        log.debug(UNITS + bValue + ": " + units + CONVERTED_TO + mbValue + " MBs");
                    }
                    outputValue = mbValue + "";
                } else if (units.equalsIgnoreCase("$")
                        || units.equalsIgnoreCase("Dollar")
                        || units.equalsIgnoreCase("Dollars")) {
                    String dollarValue = bucketValue;
                    if (StringUtils.isEmpty(dollarValue)) {
                        dollarValue = "0";
                    }
                    outputValue = dollarValue;
                } else if (units.equalsIgnoreCase("CENT")
                        || units.equalsIgnoreCase("CENTS")) {
                    String centValue = bucketValue;
                    if (StringUtils.isEmpty(centValue)) {
                        centValue = "0";
                    }
                    double dollarValue = 0;
                    dollarValue = new Double(centValue) / 100;
                    log.debug(UNITS + centValue + ": " + units + CONVERTED_TO + dollarValue + " Dollars");
                    outputValue = dollarValue + "";
                } else {
                    outputValue = bucketValue;
                    log.debug("Output Value: " + outputValue + " " + units);
                }
            } else {
                log.debug("No UNIT value returned from the Carrier");
                outputValue = bucketValue;
            }
        } catch (NumberFormatException e) {
            log.error("Exception during unit convertion");
            outputValue = bucketValue;
        }

        if (StringUtils.isEmpty(outputValue)) {
            outputValue = "0";
        }

        log.debug("Bucket Value: " + bucketValue + " Converted to : " + outputValue);
        return outputValue;
    }

    public static TFOneCarrierSubscriber populateTFOneCarrierSubscriberWithBuckets(QuerySubscriberDetailsResponseV3 response, TFOneCarrierSubscriber subscriber) {
        List<Response> responses = response.getBody().getResponse();
        if (!responses.isEmpty()) {
            ResultTypeV3 result = responses.get(0).getQuerySubscriberDetails().getResult().get(0);

            if (result.getResult().equals("100")) {
                QuerySubscriberDetailsResponseTypeV3 querySubscriberDetails = responses.get(0)
                        .getQuerySubscriberDetails();
                BaseProductTypeV4 baseProductTypeV4 = querySubscriberDetails.getBaseProduct();
                subscriber.setBuckets(buildBucketsAndTiers(baseProductTypeV4));
            } else {
                log.info(result.getResult() + ":" + result.getResultMsg());
            }
        }
        return subscriber;
    }

    private static void setRatePlanName(TFOneCarrierSubscriber subscriber, BaseProductTypeV4 baseProductTypeV4) {
        StringBuilder ratePlanName = new StringBuilder(baseProductTypeV4.getBaseProductID());
        ratePlanName.append("|").append(baseProductTypeV4.getWPS().get(0).getValue());
        subscriber.getRateplanProfile().setRatePlanName(ratePlanName.toString());
    }

    private static NodeList getValueFromXPath(String carrierResponse, String xPath) {
        NodeList nodeList = null;
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            docBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            docBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            // Disable external DTDs as well
            docBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new InputSource(new StringReader(carrierResponse)));
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile(xPath);
            nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        } catch (Exception e) {
            log.error(e);
            throw new TFMicroServiceException(MS_002_ERROR_CODE, MS_002_ERROR_MESSAGE);
        }

        return nodeList;
    }

}
