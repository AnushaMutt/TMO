package com.tracfone.inquiry.tmobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InquiryTmobileApplication {

    public static void main(String[] args) {
        SpringApplication.run(InquiryTmobileApplication.class, args);
    }
}