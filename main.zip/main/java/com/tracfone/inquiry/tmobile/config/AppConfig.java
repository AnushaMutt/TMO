package com.tracfone.inquiry.tmobile.config;

import com.tracfone.inquiry.tmobile.filter.CorrelationIDFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AppConfig {

    @Bean
    public FilterRegistrationBean<CorrelationIDFilter> servletRegistrationBean() {
        FilterRegistrationBean<CorrelationIDFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new CorrelationIDFilter());
        registrationBean.setOrder(Ordered.LOWEST_PRECEDENCE);
        return registrationBean;
    }

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate;
    }

    @Bean
    public WebClient webClient(WebClient.Builder webClientBuilder) {
        return webClientBuilder.build();
    }
}
