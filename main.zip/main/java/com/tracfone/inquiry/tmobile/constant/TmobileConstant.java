package com.tracfone.inquiry.tmobile.constant;

public class TmobileConstant {

    public static final int PARTNER_ID = 138;
    public static final String BI = "BI_";
    public static final String QUERY_SUBSCRIBER_USAGE = "QuerySubscriberUsage";
    public static final String SUBSCRIBER_INQUIRY = "SubscriberInquiry";
    public static final String CALLBACK_URL = "https://carriergateway.tracfone.com/igate/tmobileBulk/1";
    public static final String TETHER = "TETHER";
    public static final String QUERY_SIM = "QuerySIM";
    public static final String QS = "QS_";
    public static final String QAR = "QAR_";
    public static final String QUERY_SIM2 = "QuerySIMV2";

    public static final String FORMAT_DATE = "MM/dd/yyyy hh:mm:ss a";
    public static final String RESPONSE_ERROR = "Error when retrieving data from response";
    public static final String UNITS= "Units ";
    public static final String CONVERTED_TO = ", converted to ";
    public static final String REQUEST_RECEIVED= "Request received = sim:";
    public static final String RESPONSE = "response ";
    public static final String SERVICE_URL = "Service URL : {}";
    public static final String SENDING_REQUEST = "Sending Request to Carrier for query network";
    public static final String XML_REQUEST = "xmlStringRequest : {}";
    public static final String EXCEPTION_OCCURED = "Exception occurred while fetching calling QueryNetwork: {}";
    public static final String RESPONSE_RECEIVED = "response received from QueryNetwork ";
}
